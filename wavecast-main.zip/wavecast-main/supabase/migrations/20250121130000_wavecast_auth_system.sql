-- WaveCast Music Streaming Platform - Authentication & User Management Module
-- Location: supabase/migrations/20250121130000_wavecast_auth_system.sql

-- 1. Custom Types
CREATE TYPE public.user_role AS ENUM ('user', 'artist', 'admin');
CREATE TYPE public.account_status AS ENUM ('active', 'suspended', 'pending_verification');
CREATE TYPE public.verification_status AS ENUM ('unverified', 'pending', 'verified', 'rejected');

-- 2. Core User Profiles Table (Intermediary for auth relationships)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    username TEXT UNIQUE,
    full_name TEXT NOT NULL,
    avatar_url TEXT,
    bio TEXT,
    role public.user_role DEFAULT 'user'::public.user_role,
    account_status public.account_status DEFAULT 'active'::public.account_status,
    verification_status public.verification_status DEFAULT 'unverified'::public.verification_status,
    is_verified_artist BOOLEAN DEFAULT false,
    followers_count INTEGER DEFAULT 0,
    following_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Artist Profiles (Extended information for artists)
CREATE TABLE public.artist_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    artist_name TEXT NOT NULL,
    genre_primary TEXT,
    genres_secondary TEXT[],
    verified_at TIMESTAMPTZ,
    monthly_listeners INTEGER DEFAULT 0,
    total_plays INTEGER DEFAULT 0,
    total_likes INTEGER DEFAULT 0,
    social_links JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. User Social Connections
CREATE TABLE public.user_follows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    follower_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    following_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(follower_id, following_id)
);

-- 5. User Settings and Preferences
CREATE TABLE public.user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    music_quality TEXT DEFAULT 'high',
    auto_play BOOLEAN DEFAULT true,
    explicit_content BOOLEAN DEFAULT true,
    notifications_enabled BOOLEAN DEFAULT true,
    social_features_enabled BOOLEAN DEFAULT true,
    privacy_profile TEXT DEFAULT 'public',
    preferred_genres TEXT[],
    language TEXT DEFAULT 'en',
    theme TEXT DEFAULT 'dark',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Essential Indexes
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX idx_user_profiles_verification_status ON public.user_profiles(verification_status);
CREATE INDEX idx_user_profiles_username ON public.user_profiles(username);
CREATE INDEX idx_artist_profiles_user_id ON public.artist_profiles(user_id);
CREATE INDEX idx_artist_profiles_verified ON public.artist_profiles(verified_at);
CREATE INDEX idx_user_follows_follower ON public.user_follows(follower_id);
CREATE INDEX idx_user_follows_following ON public.user_follows(following_id);
CREATE INDEX idx_user_preferences_user_id ON public.user_preferences(user_id);

-- 7. Enable Row Level Security
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.artist_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;

-- 8. Safe Helper Functions
CREATE OR REPLACE FUNCTION public.is_own_profile(profile_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = profile_id AND up.id = auth.uid()
)
$$;

CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = auth.uid() AND up.role = 'admin'::public.user_role
)
$$;

CREATE OR REPLACE FUNCTION public.can_view_profile(profile_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    JOIN public.user_preferences pref ON up.id = pref.user_id
    WHERE up.id = profile_id 
    AND (pref.privacy_profile = 'public' OR up.id = auth.uid() OR public.is_admin_user())
)
$$;

CREATE OR REPLACE FUNCTION public.can_follow_user(target_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = target_user_id 
    AND up.id != auth.uid()
    AND up.account_status = 'active'::public.account_status
)
$$;

-- 9. Automatic Profile Creation Function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name, username)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1))
  );
  
  INSERT INTO public.user_preferences (user_id)
  VALUES (NEW.id);
  
  RETURN NEW;
END;
$$;

-- 10. Update Followers Count Function
CREATE OR REPLACE FUNCTION public.update_followers_count()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Increment follower count for the user being followed
    UPDATE public.user_profiles 
    SET followers_count = followers_count + 1 
    WHERE id = NEW.following_id;
    
    -- Increment following count for the user doing the following
    UPDATE public.user_profiles 
    SET following_count = following_count + 1 
    WHERE id = NEW.follower_id;
    
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    -- Decrement follower count for the user being unfollowed
    UPDATE public.user_profiles 
    SET followers_count = GREATEST(followers_count - 1, 0) 
    WHERE id = OLD.following_id;
    
    -- Decrement following count for the user doing the unfollowing
    UPDATE public.user_profiles 
    SET following_count = GREATEST(following_count - 1, 0) 
    WHERE id = OLD.follower_id;
    
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

-- 11. Update Timestamps Function
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

-- 12. Triggers
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER on_user_follow_change
  AFTER INSERT OR DELETE ON public.user_follows
  FOR EACH ROW EXECUTE FUNCTION public.update_followers_count();

CREATE TRIGGER update_user_profiles_timestamp
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_artist_profiles_timestamp
  BEFORE UPDATE ON public.artist_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_user_preferences_timestamp
  BEFORE UPDATE ON public.user_preferences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- 13. RLS Policies
-- User Profiles Policies
CREATE POLICY "users_view_public_profiles" ON public.user_profiles
FOR SELECT TO authenticated
USING (public.can_view_profile(id));

CREATE POLICY "users_update_own_profile" ON public.user_profiles
FOR UPDATE TO authenticated
USING (public.is_own_profile(id))
WITH CHECK (public.is_own_profile(id));

CREATE POLICY "admins_manage_all_profiles" ON public.user_profiles
FOR ALL TO authenticated
USING (public.is_admin_user())
WITH CHECK (public.is_admin_user());

-- Artist Profiles Policies
CREATE POLICY "public_view_artist_profiles" ON public.artist_profiles
FOR SELECT TO authenticated
USING (true);

CREATE POLICY "artists_manage_own_profile" ON public.artist_profiles
FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "admins_manage_artist_profiles" ON public.artist_profiles
FOR ALL TO authenticated
USING (public.is_admin_user())
WITH CHECK (public.is_admin_user());

-- User Follows Policies
CREATE POLICY "users_view_own_follows" ON public.user_follows
FOR SELECT TO authenticated
USING (follower_id = auth.uid() OR following_id = auth.uid());

CREATE POLICY "users_manage_own_follows" ON public.user_follows
FOR INSERT TO authenticated
WITH CHECK (follower_id = auth.uid() AND public.can_follow_user(following_id));

CREATE POLICY "users_delete_own_follows" ON public.user_follows
FOR DELETE TO authenticated
USING (follower_id = auth.uid());

-- User Preferences Policies
CREATE POLICY "users_manage_own_preferences" ON public.user_preferences
FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 14. Mock Data
DO $$
DECLARE
    admin_uuid UUID := gen_random_uuid();
    artist_uuid UUID := gen_random_uuid();
    user_uuid UUID := gen_random_uuid();
    artist_profile_id UUID := gen_random_uuid();
BEGIN
    -- Create complete auth.users records
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@wavecast.com', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "WaveCast Admin", "username": "wavecast_admin"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (artist_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'artist@wavecast.com', crypt('artist123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "DJ Phoenix", "username": "dj_phoenix"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (user_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'user@wavecast.com', crypt('user123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Music Lover", "username": "music_lover"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Update user profiles with roles
    UPDATE public.user_profiles SET role = 'admin'::public.user_role WHERE id = admin_uuid;
    UPDATE public.user_profiles SET role = 'artist'::public.user_role, is_verified_artist = true WHERE id = artist_uuid;

    -- Create artist profile
    INSERT INTO public.artist_profiles (id, user_id, artist_name, genre_primary, genres_secondary, verified_at, monthly_listeners, total_plays)
    VALUES (artist_profile_id, artist_uuid, 'DJ Phoenix', 'Electronic', ARRAY['House', 'Techno', 'Progressive'], now(), 15000, 250000);

    -- Create some follow relationships
    INSERT INTO public.user_follows (follower_id, following_id)
    VALUES 
        (user_uuid, artist_uuid),
        (admin_uuid, artist_uuid);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error: %', SQLERRM;
END $$;

-- 15. Cleanup Function for Development
CREATE OR REPLACE FUNCTION public.cleanup_test_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    auth_user_ids_to_delete UUID[];
BEGIN
    SELECT ARRAY_AGG(id) INTO auth_user_ids_to_delete
    FROM auth.users
    WHERE email LIKE '%@wavecast.com';

    DELETE FROM public.user_follows WHERE follower_id = ANY(auth_user_ids_to_delete) OR following_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.artist_profiles WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.user_preferences WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.user_profiles WHERE id = ANY(auth_user_ids_to_delete);
    DELETE FROM auth.users WHERE id = ANY(auth_user_ids_to_delete);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key constraint prevents deletion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END;
$$;