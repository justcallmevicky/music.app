import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  late final SupabaseClient _client;

  factory AuthService() => _instance;

  AuthService._internal() {
    _initializeClient();
  }

  Future<void> _initializeClient() async {
    _client = await SupabaseService().client;
  }

  // Auth state management
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;
  User? get currentUser => _client.auth.currentUser;
  Session? get currentSession => _client.auth.currentSession;
  bool get isAuthenticated => currentUser != null;

  /// Sign up with email and password
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    String? fullName,
    String? username,
  }) async {
    try {
      final response = await _client.auth.signUp(
        email: email,
        password: password,
        data: {
          if (fullName != null) 'full_name': fullName,
          if (username != null) 'username': username,
        },
      );
      return response;
    } catch (error) {
      throw Exception('Sign-up failed: $error');
    }
  }

  /// Sign in with email and password
  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      return response;
    } catch (error) {
      throw Exception('Sign-in failed: $error');
    }
  }

  /// OAuth Sign-in with Google
  Future<bool> signInWithGoogle() async {
    try {
      return await _client.auth.signInWithOAuth(OAuthProvider.google);
    } catch (error) {
      throw Exception('Google sign-in failed: $error');
    }
  }

  /// Sign out
  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } catch (error) {
      throw Exception('Sign-out failed: $error');
    }
  }

  /// Reset password
  Future<void> resetPassword(String email) async {
    try {
      await _client.auth.resetPasswordForEmail(email);
    } catch (error) {
      throw Exception('Password reset failed: $error');
    }
  }

  /// Update user profile
  Future<UserResponse> updateProfile({
    String? fullName,
    String? username,
    String? avatarUrl,
  }) async {
    try {
      final response = await _client.auth.updateUser(
        UserAttributes(
          data: {
            if (fullName != null) 'full_name': fullName,
            if (username != null) 'username': username,
            if (avatarUrl != null) 'avatar_url': avatarUrl,
          },
        ),
      );
      return response;
    } catch (error) {
      throw Exception('Profile update failed: $error');
    }
  }

  /// Get current user profile from database
  Future<Map<String, dynamic>?> getCurrentUserProfile() async {
    try {
      if (!isAuthenticated) return null;

      final response = await _client
          .from('user_profiles')
          .select('*, artist_profiles(*), user_preferences(*)')
          .eq('id', currentUser!.id)
          .maybeSingle();

      return response;
    } catch (error) {
      throw Exception('Failed to fetch user profile: $error');
    }
  }

  /// Update user profile in database
  Future<void> updateUserProfile({
    String? fullName,
    String? username,
    String? bio,
    String? avatarUrl,
  }) async {
    try {
      if (!isAuthenticated) throw Exception('User not authenticated');

      await _client.from('user_profiles').update({
        if (fullName != null) 'full_name': fullName,
        if (username != null) 'username': username,
        if (bio != null) 'bio': bio,
        if (avatarUrl != null) 'avatar_url': avatarUrl,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', currentUser!.id);
    } catch (error) {
      throw Exception('Failed to update profile: $error');
    }
  }

  /// Create artist profile
  Future<void> createArtistProfile({
    required String artistName,
    required String primaryGenre,
    List<String>? secondaryGenres,
    Map<String, String>? socialLinks,
  }) async {
    try {
      if (!isAuthenticated) throw Exception('User not authenticated');

      // Update user role to artist
      await _client.from('user_profiles').update({
        'role': 'artist',
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', currentUser!.id);

      // Create artist profile
      await _client.from('artist_profiles').insert({
        'user_id': currentUser!.id,
        'artist_name': artistName,
        'genre_primary': primaryGenre,
        'genres_secondary': secondaryGenres,
        'social_links': socialLinks ?? {},
      });
    } catch (error) {
      throw Exception('Failed to create artist profile: $error');
    }
  }

  /// Follow/Unfollow user
  Future<void> toggleFollow(String targetUserId) async {
    try {
      if (!isAuthenticated) throw Exception('User not authenticated');

      // Check if already following
      final existing = await _client
          .from('user_follows')
          .select('id')
          .eq('follower_id', currentUser!.id)
          .eq('following_id', targetUserId)
          .maybeSingle();

      if (existing != null) {
        // Unfollow
        await _client
            .from('user_follows')
            .delete()
            .eq('follower_id', currentUser!.id)
            .eq('following_id', targetUserId);
      } else {
        // Follow
        await _client.from('user_follows').insert({
          'follower_id': currentUser!.id,
          'following_id': targetUserId,
        });
      }
    } catch (error) {
      throw Exception('Failed to toggle follow: $error');
    }
  }

  /// Check if following a user
  Future<bool> isFollowing(String targetUserId) async {
    try {
      if (!isAuthenticated) return false;

      final response = await _client
          .from('user_follows')
          .select('id')
          .eq('follower_id', currentUser!.id)
          .eq('following_id', targetUserId)
          .maybeSingle();

      return response != null;
    } catch (error) {
      return false;
    }
  }

  /// Get user followers
  Future<List<Map<String, dynamic>>> getFollowers(String userId) async {
    try {
      final response = await _client
          .from('user_follows')
          .select('follower_id, user_profiles!user_follows_follower_id_fkey(*)')
          .eq('following_id', userId);

      return List<Map<String, dynamic>>.from(response);
    } catch (error) {
      throw Exception('Failed to fetch followers: $error');
    }
  }

  /// Get user following
  Future<List<Map<String, dynamic>>> getFollowing(String userId) async {
    try {
      final response = await _client
          .from('user_follows')
          .select(
              'following_id, user_profiles!user_follows_following_id_fkey(*)')
          .eq('follower_id', userId);

      return List<Map<String, dynamic>>.from(response);
    } catch (error) {
      throw Exception('Failed to fetch following: $error');
    }
  }
}
