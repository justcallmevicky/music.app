import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';

class UserService {
  static final UserService _instance = UserService._internal();
  late final SupabaseClient _client;

  factory UserService() => _instance;

  UserService._internal() {
    _initializeClient();
  }

  Future<void> _initializeClient() async {
    _client = await SupabaseService().client;
  }

  /// Search users by username or full name
  Future<List<Map<String, dynamic>>> searchUsers({
    required String query,
    int limit = 20,
  }) async {
    try {
      final response = await _client
          .from('user_profiles')
          .select(
              'id, username, full_name, avatar_url, bio, role, is_verified_artist, followers_count')
          .or('username.ilike.%$query%,full_name.ilike.%$query%')
          .eq('account_status', 'active')
          .order('followers_count', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (error) {
      throw Exception('Failed to search users: $error');
    }
  }

  /// Get user profile by ID
  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final response = await _client
          .from('user_profiles')
          .select('*, artist_profiles(*)')
          .eq('id', userId)
          .maybeSingle();

      return response;
    } catch (error) {
      throw Exception('Failed to fetch user profile: $error');
    }
  }

  /// Get verified artists
  Future<List<Map<String, dynamic>>> getVerifiedArtists({
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      final response = await _client
          .from('user_profiles')
          .select('*, artist_profiles(*)')
          .eq('role', 'artist')
          .eq('is_verified_artist', true)
          .eq('account_status', 'active')
          .order('followers_count', ascending: false)
          .range(offset, offset + limit - 1);

      return List<Map<String, dynamic>>.from(response);
    } catch (error) {
      throw Exception('Failed to fetch verified artists: $error');
    }
  }

  /// Get trending artists
  Future<List<Map<String, dynamic>>> getTrendingArtists({
    int limit = 20,
  }) async {
    try {
      final response = await _client
          .from('artist_profiles')
          .select('*, user_profiles(*)')
          .order('monthly_listeners', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (error) {
      throw Exception('Failed to fetch trending artists: $error');
    }
  }

  /// Update user preferences
  Future<void> updateUserPreferences({
    String? musicQuality,
    bool? autoPlay,
    bool? explicitContent,
    bool? notificationsEnabled,
    bool? socialFeaturesEnabled,
    String? privacyProfile,
    List<String>? preferredGenres,
    String? language,
    String? theme,
  }) async {
    try {
      final userId = SupabaseService().currentUser?.id;
      if (userId == null) throw Exception('User not authenticated');

      await _client.from('user_preferences').upsert({
        'user_id': userId,
        if (musicQuality != null) 'music_quality': musicQuality,
        if (autoPlay != null) 'auto_play': autoPlay,
        if (explicitContent != null) 'explicit_content': explicitContent,
        if (notificationsEnabled != null)
          'notifications_enabled': notificationsEnabled,
        if (socialFeaturesEnabled != null)
          'social_features_enabled': socialFeaturesEnabled,
        if (privacyProfile != null) 'privacy_profile': privacyProfile,
        if (preferredGenres != null) 'preferred_genres': preferredGenres,
        if (language != null) 'language': language,
        if (theme != null) 'theme': theme,
        'updated_at': DateTime.now().toIso8601String(),
      });
    } catch (error) {
      throw Exception('Failed to update preferences: $error');
    }
  }

  /// Get user preferences
  Future<Map<String, dynamic>?> getUserPreferences(String userId) async {
    try {
      final response = await _client
          .from('user_preferences')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle();

      return response;
    } catch (error) {
      throw Exception('Failed to fetch user preferences: $error');
    }
  }

  /// Get user statistics
  Future<Map<String, dynamic>> getUserStats(String userId) async {
    try {
      final results = await Future.wait([
        // Get follower count
        _client
            .from('user_follows')
            .select()
            .eq('following_id', userId)
            .count(),

        // Get following count
        _client.from('user_follows').select().eq('follower_id', userId).count(),
      ]);

      return {
        'followers_count': results[0].count ?? 0,
        'following_count': results[1].count ?? 0,
      };
    } catch (error) {
      throw Exception('Failed to fetch user stats: $error');
    }
  }

  /// Report user
  Future<void> reportUser({
    required String reportedUserId,
    required String reason,
    String? description,
  }) async {
    try {
      final currentUserId = SupabaseService().currentUser?.id;
      if (currentUserId == null) throw Exception('User not authenticated');

      // This would typically go to a reports table (to be implemented in content module)
      // For now, we'll use a simple logging approach
      await _client.from('user_reports').insert({
        'reporter_id': currentUserId,
        'reported_user_id': reportedUserId,
        'reason': reason,
        'description': description,
        'status': 'pending',
        'created_at': DateTime.now().toIso8601String(),
      });
    } catch (error) {
      // Fail silently for now since reports table doesn't exist yet
      print('Report functionality will be implemented in admin module: $error');
    }
  }

  /// Block user
  Future<void> blockUser(String targetUserId) async {
    try {
      final currentUserId = SupabaseService().currentUser?.id;
      if (currentUserId == null) throw Exception('User not authenticated');

      // Remove any existing follow relationship
      await _client
          .from('user_follows')
          .delete()
          .or('follower_id.eq.$currentUserId,following_id.eq.$currentUserId')
          .or('follower_id.eq.$targetUserId,following_id.eq.$targetUserId');

      // Block functionality would be implemented in a user_blocks table
      // This will be part of the social features module
    } catch (error) {
      throw Exception('Failed to block user: $error');
    }
  }
}
