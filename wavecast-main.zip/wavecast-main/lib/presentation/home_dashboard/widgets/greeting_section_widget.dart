import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class GreetingSectionWidget extends StatelessWidget {
  final Map<String, dynamic>? userProfile;

  const GreetingSectionWidget({
    Key? key,
    this.userProfile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final userName = userProfile?['full_name'] ?? 'Music Lover';
    final isArtist = userProfile?['role'] == 'artist';
    final isVerified = userProfile?['is_verified_artist'] == true;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).colorScheme.primary.withAlpha(26),
            Theme.of(context).colorScheme.primary.withAlpha(13),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Welcome back, $userName!',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
              if (isArtist && isVerified) ...[
                Icon(
                  Icons.verified,
                  color: Theme.of(context).colorScheme.primary,
                  size: 6.w,
                ),
              ],
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            _getPersonalizedMessage(userProfile),
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).textTheme.bodySmall?.color,
                ),
          ),
          if (userProfile != null) ...[
            SizedBox(height: 2.h),

            // Quick Stats or Actions
            Row(
              children: [
                if (isArtist) ...[
                  _buildQuickStat(
                    context,
                    'Followers',
                    '${userProfile!['followers_count'] ?? 0}',
                    Icons.people,
                  ),
                  SizedBox(width: 4.w),
                  _buildQuickStat(
                    context,
                    'Tracks',
                    '0', // Will be updated when tracks module is implemented
                    Icons.music_note,
                  ),
                ] else ...[
                  _buildQuickStat(
                    context,
                    'Following',
                    '${userProfile!['following_count'] ?? 0}',
                    Icons.favorite,
                  ),
                  SizedBox(width: 4.w),
                  _buildQuickStat(
                    context,
                    'Playlists',
                    '0', // Will be updated when playlists module is implemented
                    Icons.playlist_play,
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildQuickStat(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withAlpha(26),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 4.w,
            color: Theme.of(context).colorScheme.primary,
          ),
          SizedBox(width: 1.w),
          Text(
            '$value $label',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
          ),
        ],
      ),
    );
  }

  String _getPersonalizedMessage(Map<String, dynamic>? profile) {
    if (profile == null) return 'Ready to discover amazing music?';

    final role = profile['role'];
    final hour = DateTime.now().hour;

    if (role == 'artist') {
      if (hour < 12) {
        return 'Ready to create something amazing today?';
      } else if (hour < 17) {
        return 'Time to share your music with the world!';
      } else {
        return 'Perfect evening for inspiration and creativity!';
      }
    } else {
      if (hour < 12) {
        return 'Start your day with your favorite tunes!';
      } else if (hour < 17) {
        return 'Discover new music to brighten your afternoon!';
      } else {
        return 'Unwind with some relaxing melodies tonight!';
      }
    }
  }
}
