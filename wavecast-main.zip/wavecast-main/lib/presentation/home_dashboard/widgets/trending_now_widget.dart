import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TrendingNowWidget extends StatefulWidget {
  final List<Map<String, dynamic>> trendingSongs;
  final Function(Map<String, dynamic>) onSongPlay;
  final Function(Map<String, dynamic>) onSongLike;

  const TrendingNowWidget({
    Key? key,
    required this.trendingSongs,
    required this.onSongPlay,
    required this.onSongLike,
  }) : super(key: key);

  @override
  State<TrendingNowWidget> createState() => _TrendingNowWidgetState();
}

class _TrendingNowWidgetState extends State<TrendingNowWidget> {
  Set<int> likedSongs = {};

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Text(
              'Trending Now',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            height: 22.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              itemCount: widget.trendingSongs.length,
              itemBuilder: (context, index) {
                final song = widget.trendingSongs[index];
                final isLiked = likedSongs.contains(song['id'] as int);

                return Container(
                  width: 45.w,
                  margin: EdgeInsets.only(right: 3.w),
                  child: Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: double.infinity,
                          height: 12.h,
                          child: Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(12),
                                ),
                                child: CustomImageWidget(
                                  imageUrl: song['albumArt'] as String,
                                  width: double.infinity,
                                  height: 12.h,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(12),
                                  ),
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.transparent,
                                      Colors.black.withValues(alpha: 0.4),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 1.h,
                                left: 2.w,
                                child: GestureDetector(
                                  onTap: () => widget.onSongPlay(song),
                                  child: Container(
                                    padding: EdgeInsets.all(1.5.w),
                                    decoration: BoxDecoration(
                                      color: AppTheme.primaryLight,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: CustomIconWidget(
                                      iconName: 'play_arrow',
                                      color: Colors.white,
                                      size: 4.w,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 1.h,
                                right: 2.w,
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      isLiked
                                          ? likedSongs.remove(song['id'] as int)
                                          : likedSongs.add(song['id'] as int);
                                    });
                                    widget.onSongLike(song);
                                  },
                                  child: Container(
                                    padding: EdgeInsets.all(1.5.w),
                                    decoration: BoxDecoration(
                                      color:
                                          Colors.white.withValues(alpha: 0.9),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: CustomIconWidget(
                                      iconName: isLiked
                                          ? 'favorite'
                                          : 'favorite_border',
                                      color: isLiked
                                          ? Colors.red
                                          : Colors.grey[600]!,
                                      size: 4.w,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.all(2.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  song['title'] as String,
                                  style: AppTheme
                                      .lightTheme.textTheme.titleSmall
                                      ?.copyWith(
                                    fontWeight: FontWeight.w500,
                                    color:
                                        Theme.of(context).colorScheme.onSurface,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                ),
                                SizedBox(height: 0.5.h),
                                Text(
                                  song['artist'] as String,
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                ),
                                Spacer(),
                                Row(
                                  children: [
                                    CustomIconWidget(
                                      iconName: 'trending_up',
                                      color: AppTheme.primaryLight,
                                      size: 3.w,
                                    ),
                                    SizedBox(width: 1.w),
                                    Text(
                                      '${song['plays']}',
                                      style: AppTheme
                                          .lightTheme.textTheme.bodySmall
                                          ?.copyWith(
                                        color: AppTheme.primaryLight,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
