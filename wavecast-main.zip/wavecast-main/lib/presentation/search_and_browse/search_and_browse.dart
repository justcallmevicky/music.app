import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/category_grid_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/recent_searches_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/search_results_widget.dart';
import './widgets/trending_searches_widget.dart';
import './widgets/voice_search_widget.dart';

class SearchAndBrowse extends StatefulWidget {
  const SearchAndBrowse({Key? key}) : super(key: key);

  @override
  State<SearchAndBrowse> createState() => _SearchAndBrowseState();
}

class _SearchAndBrowseState extends State<SearchAndBrowse> {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;
  bool _showVoiceSearch = false;
  Map<String, dynamic> _currentFilters = {};

  // Mock data for recent searches
  List<String> _recentSearches = [
    'Taylor Swift',
    'Jazz playlist',
    'Workout music',
    'The Weeknd',
  ];

  // Mock data for trending searches
  final List<String> _trendingSearches = [
    'Bad Bunny - Un Verano Sin Ti',
    'Harry Styles - As It Was',
    'Dua Lipa - Levitating',
    'The Weeknd - Blinding Lights',
    'Olivia Rodrigo - Good 4 U',
    'Drake - God\'s Plan',
    'Billie Eilish - Bad Guy',
    'Post Malone - Circles',
  ];

  // Mock data for categories
  final List<Map<String, dynamic>> _categories = [
    {
      "name": "Rock",
      "image":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "color": 0xFFE91E63,
    },
    {
      "name": "Pop",
      "image":
          "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
      "color": 0xFF9C27B0,
    },
    {
      "name": "Hip-Hop",
      "image":
          "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&h=300&fit=crop",
      "color": 0xFF673AB7,
    },
    {
      "name": "Jazz",
      "image":
          "https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?w=300&h=300&fit=crop",
      "color": 0xFF3F51B5,
    },
    {
      "name": "Chill",
      "image":
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=300&fit=crop",
      "color": 0xFF2196F3,
    },
    {
      "name": "Workout",
      "image":
          "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&h=300&fit=crop",
      "color": 0xFF03DAC6,
    },
    {
      "name": "90s Hits",
      "image":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "color": 0xFF4CAF50,
    },
    {
      "name": "2000s",
      "image":
          "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
      "color": 0xFF8BC34A,
    },
  ];

  // Mock search results
  Map<String, List<Map<String, dynamic>>> _searchResults = {};

  @override
  void initState() {
    super.initState();
    _generateMockSearchResults();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _generateMockSearchResults() {
    _searchResults = {
      'songs': [
        {
          "id": 1,
          "title": "As It Was",
          "artist": "Harry Styles",
          "artwork":
              "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
          "duration": "2:47",
        },
        {
          "id": 2,
          "title": "Bad Habit",
          "artist": "Steve Lacy",
          "artwork":
              "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
          "duration": "3:51",
        },
        {
          "id": 3,
          "title": "Anti-Hero",
          "artist": "Taylor Swift",
          "artwork":
              "https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?w=300&h=300&fit=crop",
          "duration": "3:20",
        },
      ],
      'artists': [
        {
          "id": 1,
          "name": "Harry Styles",
          "profileImage":
              "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop",
          "followers": "47.2M",
          "isFollowing": false,
        },
        {
          "id": 2,
          "name": "Taylor Swift",
          "profileImage":
              "https://images.unsplash.com/photo-1494790108755-2616c9c0e8d3?w=300&h=300&fit=crop",
          "followers": "89.1M",
          "isFollowing": true,
        },
        {
          "id": 3,
          "name": "The Weeknd",
          "profileImage":
              "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop",
          "followers": "32.8M",
          "isFollowing": false,
        },
      ],
      'playlists': [
        {
          "id": 1,
          "name": "Today's Top Hits",
          "creator": "Spotify",
          "artwork":
              "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
          "songCount": 50,
        },
        {
          "id": 2,
          "name": "RapCaviar",
          "creator": "Spotify",
          "artwork":
              "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&h=300&fit=crop",
          "songCount": 65,
        },
        {
          "id": 3,
          "name": "Chill Hits",
          "creator": "Spotify",
          "artwork":
              "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=300&fit=crop",
          "songCount": 100,
        },
      ],
      'users': [
        {
          "id": 1,
          "username": "musiclover23",
          "profileImage":
              "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop",
          "mutualConnections": 5,
        },
        {
          "id": 2,
          "username": "jazzfan_sarah",
          "profileImage":
              "https://images.unsplash.com/photo-1494790108755-2616c9c0e8d3?w=300&h=300&fit=crop",
          "mutualConnections": 12,
        },
        {
          "id": 3,
          "username": "rockstar_mike",
          "profileImage":
              "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop",
          "mutualConnections": null,
        },
      ],
    };
  }

  void _onSearchChanged(String query) {
    setState(() {
      _isSearching = query.isNotEmpty;
    });

    if (query.isNotEmpty && !_recentSearches.contains(query)) {
      setState(() {
        _recentSearches.insert(0, query);
        if (_recentSearches.length > 10) {
          _recentSearches.removeLast();
        }
      });
    }
  }

  void _onVoiceSearch() {
    setState(() {
      _showVoiceSearch = true;
    });
  }

  void _onVoiceResult(String result) {
    setState(() {
      _showVoiceSearch = false;
      _searchController.text = result;
      _isSearching = true;
    });
  }

  void _onRemoveSearch(String search) {
    setState(() {
      _recentSearches.remove(search);
    });
  }

  void _onTrendingTap(String trending) {
    setState(() {
      _searchController.text = trending;
      _isSearching = true;
    });
  }

  void _onCategoryTap(Map<String, dynamic> category) {
    setState(() {
      _searchController.text = category["name"] as String;
      _isSearching = true;
    });
  }

  void _onSongTap(Map<String, dynamic> song) {
    Navigator.pushNamed(context, '/music-player');
  }

  void _onArtistTap(Map<String, dynamic> artist) {
    // Navigate to artist profile
    print('Navigate to artist: ${artist["name"]}');
  }

  void _onPlaylistTap(Map<String, dynamic> playlist) {
    Navigator.pushNamed(context, '/playlist-management');
  }

  void _onUserTap(Map<String, dynamic> user) {
    // Navigate to user profile
    print('Navigate to user: ${user["username"]}');
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _currentFilters,
        onFiltersApplied: (filters) {
          setState(() {
            _currentFilters = filters;
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Search Bar
                SearchBarWidget(
                  onSearchChanged: _onSearchChanged,
                  onVoiceSearch: _onVoiceSearch,
                  searchController: _searchController,
                ),

                // Filter Button (shown when searching)
                if (_isSearching) ...[
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton.icon(
                          onPressed: _showFilterBottomSheet,
                          icon: CustomIconWidget(
                            iconName: 'tune',
                            color: AppTheme.lightTheme.primaryColor,
                            size: 4.w,
                          ),
                          label: Text(
                            'Filter',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.lightTheme.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // Content
                Expanded(
                  child: _isSearching
                      ? SearchResultsWidget(
                          searchResults: _searchResults,
                          onSongTap: _onSongTap,
                          onArtistTap: _onArtistTap,
                          onPlaylistTap: _onPlaylistTap,
                          onUserTap: _onUserTap,
                        )
                      : SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Recent Searches
                              RecentSearchesWidget(
                                recentSearches: _recentSearches,
                                onSearchTap: (search) {
                                  setState(() {
                                    _searchController.text = search;
                                    _isSearching = true;
                                  });
                                },
                                onRemoveSearch: _onRemoveSearch,
                              ),

                              SizedBox(height: 2.h),

                              // Trending Searches (shown when no recent searches)
                              if (_recentSearches.isEmpty) ...[
                                TrendingSearchesWidget(
                                  trendingSearches: _trendingSearches,
                                  onTrendingTap: _onTrendingTap,
                                ),
                                SizedBox(height: 2.h),
                              ],

                              // Category Grid
                              CategoryGridWidget(
                                categories: _categories,
                                onCategoryTap: _onCategoryTap,
                              ),

                              SizedBox(height: 4.h),
                            ],
                          ),
                        ),
                ),
              ],
            ),

            // Bottom Navigation Bar
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme
                      .lightTheme.bottomNavigationBarTheme.backgroundColor,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.lightTheme.colorScheme.shadow,
                      blurRadius: 8,
                      offset: Offset(0, -2),
                    ),
                  ],
                ),
                child: BottomNavigationBar(
                  type: BottomNavigationBarType.fixed,
                  currentIndex: 2, // Search tab is active
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  selectedItemColor: AppTheme.lightTheme.primaryColor,
                  unselectedItemColor:
                      AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  items: [
                    BottomNavigationBarItem(
                      icon: CustomIconWidget(
                        iconName: 'home',
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 6.w,
                      ),
                      activeIcon: CustomIconWidget(
                        iconName: 'home',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 6.w,
                      ),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: CustomIconWidget(
                        iconName: 'library_music',
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 6.w,
                      ),
                      activeIcon: CustomIconWidget(
                        iconName: 'library_music',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 6.w,
                      ),
                      label: 'Library',
                    ),
                    BottomNavigationBarItem(
                      icon: CustomIconWidget(
                        iconName: 'search',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 6.w,
                      ),
                      label: 'Search',
                    ),
                    BottomNavigationBarItem(
                      icon: CustomIconWidget(
                        iconName: 'chat',
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 6.w,
                      ),
                      activeIcon: CustomIconWidget(
                        iconName: 'chat',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 6.w,
                      ),
                      label: 'Chat',
                    ),
                    BottomNavigationBarItem(
                      icon: CustomIconWidget(
                        iconName: 'person',
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 6.w,
                      ),
                      activeIcon: CustomIconWidget(
                        iconName: 'person',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 6.w,
                      ),
                      label: 'Profile',
                    ),
                  ],
                  onTap: (index) {
                    switch (index) {
                      case 0:
                        Navigator.pushNamed(context, '/home-dashboard');
                        break;
                      case 1:
                        Navigator.pushNamed(context, '/playlist-management');
                        break;
                      case 2:
                        // Current screen - Search
                        break;
                      case 3:
                        Navigator.pushNamed(context, '/chat-and-messaging');
                        break;
                      case 4:
                        Navigator.pushNamed(context, '/login-screen');
                        break;
                    }
                  },
                ),
              ),
            ),

            // Voice Search Overlay
            if (_showVoiceSearch)
              VoiceSearchWidget(
                onVoiceResult: _onVoiceResult,
                onClose: () {
                  setState(() {
                    _showVoiceSearch = false;
                  });
                },
              ),
          ],
        ),
      ),
    );
  }
}
