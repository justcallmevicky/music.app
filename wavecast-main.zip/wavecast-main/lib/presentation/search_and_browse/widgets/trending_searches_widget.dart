import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TrendingSearchesWidget extends StatelessWidget {
  final List<String> trendingSearches;
  final Function(String) onTrendingTap;

  const TrendingSearchesWidget({
    Key? key,
    required this.trendingSearches,
    required this.onTrendingTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Row(
            children: [
              CustomIconWidget(
                iconName: 'trending_up',
                color: AppTheme.lightTheme.primaryColor,
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'Trending Searches',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          itemCount: trendingSearches.length,
          itemBuilder: (context, index) {
            final trending = trendingSearches[index];
            return ListTile(
              leading: CustomIconWidget(
                iconName: 'trending_up',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 5.w,
              ),
              title: Text(
                trending,
                style: AppTheme.lightTheme.textTheme.bodyMedium,
              ),
              trailing: CustomIconWidget(
                iconName: 'arrow_forward_ios',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 4.w,
              ),
              onTap: () => onTrendingTap(trending),
              contentPadding: EdgeInsets.symmetric(horizontal: 0),
            );
          },
        ),
      ],
    );
  }
}
