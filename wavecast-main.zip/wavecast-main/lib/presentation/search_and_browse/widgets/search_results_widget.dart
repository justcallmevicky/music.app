import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SearchResultsWidget extends StatefulWidget {
  final Map<String, List<Map<String, dynamic>>> searchResults;
  final Function(Map<String, dynamic>) onSongTap;
  final Function(Map<String, dynamic>) onArtistTap;
  final Function(Map<String, dynamic>) onPlaylistTap;
  final Function(Map<String, dynamic>) onUserTap;

  const SearchResultsWidget({
    Key? key,
    required this.searchResults,
    required this.onSongTap,
    required this.onArtistTap,
    required this.onPlaylistTap,
    required this.onUserTap,
  }) : super(key: key);

  @override
  State<SearchResultsWidget> createState() => _SearchResultsWidgetState();
}

class _SearchResultsWidgetState extends State<SearchResultsWidget>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final List<String> _tabs = ['All', 'Songs', 'Artists', 'Playlists', 'Users'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          child: TabBar(
            controller: _tabController,
            isScrollable: true,
            tabs: _tabs.map((tab) => Tab(text: tab)).toList(),
            labelColor: AppTheme.lightTheme.primaryColor,
            unselectedLabelColor:
                AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            indicatorColor: AppTheme.lightTheme.primaryColor,
            tabAlignment: TabAlignment.start,
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildAllResults(),
              _buildSongResults(),
              _buildArtistResults(),
              _buildPlaylistResults(),
              _buildUserResults(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAllResults() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget.searchResults['songs']?.isNotEmpty == true) ...[
            _buildSectionHeader('Songs'),
            _buildSongsList(widget.searchResults['songs']!.take(3).toList()),
            SizedBox(height: 2.h),
          ],
          if (widget.searchResults['artists']?.isNotEmpty == true) ...[
            _buildSectionHeader('Artists'),
            _buildArtistsList(
                widget.searchResults['artists']!.take(3).toList()),
            SizedBox(height: 2.h),
          ],
          if (widget.searchResults['playlists']?.isNotEmpty == true) ...[
            _buildSectionHeader('Playlists'),
            _buildPlaylistsList(
                widget.searchResults['playlists']!.take(3).toList()),
            SizedBox(height: 2.h),
          ],
          if (widget.searchResults['users']?.isNotEmpty == true) ...[
            _buildSectionHeader('Users'),
            _buildUsersList(widget.searchResults['users']!.take(3).toList()),
          ],
        ],
      ),
    );
  }

  Widget _buildSongResults() {
    return _buildSongsList(widget.searchResults['songs'] ?? []);
  }

  Widget _buildArtistResults() {
    return _buildArtistsList(widget.searchResults['artists'] ?? []);
  }

  Widget _buildPlaylistResults() {
    return _buildPlaylistsList(widget.searchResults['playlists'] ?? []);
  }

  Widget _buildUserResults() {
    return _buildUsersList(widget.searchResults['users'] ?? []);
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildSongsList(List<Map<String, dynamic>> songs) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: songs.length,
      itemBuilder: (context, index) {
        final song = songs[index];
        return ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CustomImageWidget(
              imageUrl: song["artwork"] as String,
              width: 12.w,
              height: 12.w,
              fit: BoxFit.cover,
            ),
          ),
          title: Text(
            song["title"] as String,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            song["artist"] as String,
            style: AppTheme.lightTheme.textTheme.bodySmall,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: GestureDetector(
            onTap: () => widget.onSongTap(song),
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.primaryColor,
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: 'play_arrow',
                color: Colors.white,
                size: 5.w,
              ),
            ),
          ),
          onTap: () => widget.onSongTap(song),
          contentPadding: EdgeInsets.symmetric(horizontal: 0),
        );
      },
    );
  }

  Widget _buildArtistsList(List<Map<String, dynamic>> artists) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: artists.length,
      itemBuilder: (context, index) {
        final artist = artists[index];
        return ListTile(
          leading: CircleAvatar(
            radius: 6.w,
            backgroundImage: NetworkImage(artist["profileImage"] as String),
          ),
          title: Text(
            artist["name"] as String,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            "${artist["followers"]} followers",
            style: AppTheme.lightTheme.textTheme.bodySmall,
          ),
          trailing: OutlinedButton(
            onPressed: () => widget.onArtistTap(artist),
            child: Text(
              artist["isFollowing"] == true ? "Following" : "Follow",
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
            style: OutlinedButton.styleFrom(
              minimumSize: Size(20.w, 4.h),
              padding: EdgeInsets.symmetric(horizontal: 3.w),
            ),
          ),
          onTap: () => widget.onArtistTap(artist),
          contentPadding: EdgeInsets.symmetric(horizontal: 0),
        );
      },
    );
  }

  Widget _buildPlaylistsList(List<Map<String, dynamic>> playlists) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: playlists.length,
      itemBuilder: (context, index) {
        final playlist = playlists[index];
        return ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CustomImageWidget(
              imageUrl: playlist["artwork"] as String,
              width: 12.w,
              height: 12.w,
              fit: BoxFit.cover,
            ),
          ),
          title: Text(
            playlist["name"] as String,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            "By ${playlist["creator"]} • ${playlist["songCount"]} songs",
            style: AppTheme.lightTheme.textTheme.bodySmall,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: CustomIconWidget(
            iconName: 'more_vert',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 5.w,
          ),
          onTap: () => widget.onPlaylistTap(playlist),
          contentPadding: EdgeInsets.symmetric(horizontal: 0),
        );
      },
    );
  }

  Widget _buildUsersList(List<Map<String, dynamic>> users) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: users.length,
      itemBuilder: (context, index) {
        final user = users[index];
        return ListTile(
          leading: CircleAvatar(
            radius: 6.w,
            backgroundImage: NetworkImage(user["profileImage"] as String),
          ),
          title: Text(
            user["username"] as String,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: user["mutualConnections"] != null
              ? Text(
                  "${user["mutualConnections"]} mutual connections",
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                )
              : null,
          trailing: OutlinedButton(
            onPressed: () => widget.onUserTap(user),
            child: Text(
              "Follow",
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
            style: OutlinedButton.styleFrom(
              minimumSize: Size(20.w, 4.h),
              padding: EdgeInsets.symmetric(horizontal: 3.w),
            ),
          ),
          onTap: () => widget.onUserTap(user),
          contentPadding: EdgeInsets.symmetric(horizontal: 0),
        );
      },
    );
  }
}
