import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SongInfoWidget extends StatefulWidget {
  final String title;
  final String artist;
  final String album;
  final bool isLiked;
  final VoidCallback? onLikeToggle;

  const SongInfoWidget({
    Key? key,
    required this.title,
    required this.artist,
    required this.album,
    this.isLiked = false,
    this.onLikeToggle,
  }) : super(key: key);

  @override
  State<SongInfoWidget> createState() => _SongInfoWidgetState();
}

class _SongInfoWidgetState extends State<SongInfoWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _scrollController;
  late Animation<Offset> _scrollAnimation;
  bool _shouldScroll = false;

  @override
  void initState() {
    super.initState();
    _scrollController = AnimationController(
      duration: const Duration(seconds: 8),
      vsync: this,
    );
    _scrollAnimation = Tween<Offset>(
      begin: const Offset(1.0, 0.0),
      end: const Offset(-1.0, 0.0),
    ).animate(CurvedAnimation(
      parent: _scrollController,
      curve: Curves.linear,
    ));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkIfScrollNeeded();
    });
  }

  void _checkIfScrollNeeded() {
    final textPainter = TextPainter(
      text: TextSpan(
        text: widget.title,
        style: AppTheme.lightTheme.textTheme.headlineSmall,
      ),
      maxLines: 1,
      textDirection: TextDirection.ltr,
    );
    textPainter.layout(maxWidth: 80.w);

    if (textPainter.didExceedMaxLines) {
      setState(() {
        _shouldScroll = true;
      });
      _scrollController.repeat();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            height: 6.h,
            child: _shouldScroll
                ? ClipRect(
                    child: AnimatedBuilder(
                      animation: _scrollAnimation,
                      builder: (context, child) {
                        return SlideTransition(
                          position: _scrollAnimation,
                          child: Text(
                            widget.title,
                            style: AppTheme.lightTheme.textTheme.headlineSmall
                                ?.copyWith(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w700,
                            ),
                            maxLines: 1,
                            textAlign: TextAlign.center,
                          ),
                        );
                      },
                    ),
                  )
                : Text(
                    widget.title,
                    style:
                        AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
          ),
          SizedBox(height: 1.h),
          Text(
            widget.artist,
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontSize: 14.sp,
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 0.5.h),
          Text(
            widget.album,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontSize: 12.sp,
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: widget.onLikeToggle,
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: widget.isLiked
                        ? AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: CustomIconWidget(
                    iconName: widget.isLiked ? 'favorite' : 'favorite_border',
                    color: widget.isLiked
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 24,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
