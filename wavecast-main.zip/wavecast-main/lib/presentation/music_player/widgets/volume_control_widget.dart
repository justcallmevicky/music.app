import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class VolumeControlWidget extends StatefulWidget {
  final double volume;
  final ValueChanged<double>? onVolumeChanged;

  const VolumeControlWidget({
    Key? key,
    required this.volume,
    this.onVolumeChanged,
  }) : super(key: key);

  @override
  State<VolumeControlWidget> createState() => _VolumeControlWidgetState();
}

class _VolumeControlWidgetState extends State<VolumeControlWidget> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.h),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                _isExpanded = !_isExpanded;
              });
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: widget.volume == 0
                      ? 'volume_off'
                      : widget.volume < 0.5
                          ? 'volume_down'
                          : 'volume_up',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Volume',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontSize: 12.sp,
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
                SizedBox(width: 1.w),
                CustomIconWidget(
                  iconName:
                      _isExpanded ? 'keyboard_arrow_up' : 'keyboard_arrow_down',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 16,
                ),
              ],
            ),
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            height: _isExpanded ? 8.h : 0,
            child: _isExpanded
                ? Column(
                    children: [
                      SizedBox(height: 2.h),
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'volume_down',
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                            size: 18,
                          ),
                          Expanded(
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                activeTrackColor:
                                    AppTheme.lightTheme.colorScheme.primary,
                                inactiveTrackColor: AppTheme
                                    .lightTheme.colorScheme.primary
                                    .withValues(alpha: 0.3),
                                thumbColor:
                                    AppTheme.lightTheme.colorScheme.primary,
                                overlayColor: AppTheme
                                    .lightTheme.colorScheme.primary
                                    .withValues(alpha: 0.2),
                                thumbShape: const RoundSliderThumbShape(
                                    enabledThumbRadius: 6.0),
                                overlayShape: const RoundSliderOverlayShape(
                                    overlayRadius: 12.0),
                                trackHeight: 3.0,
                              ),
                              child: Slider(
                                value: widget.volume,
                                onChanged: widget.onVolumeChanged,
                                min: 0.0,
                                max: 1.0,
                              ),
                            ),
                          ),
                          CustomIconWidget(
                            iconName: 'volume_up',
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                            size: 18,
                          ),
                        ],
                      ),
                    ],
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}
