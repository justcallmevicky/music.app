import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MoreOptionsBottomSheetWidget extends StatelessWidget {
  final VoidCallback? onAddToPlaylist;
  final VoidCallback? onGoToAlbum;
  final VoidCallback? onGoToArtist;
  final VoidCallback? onCrossfadeSettings;
  final VoidCallback? onAudioQuality;

  const MoreOptionsBottomSheetWidget({
    Key? key,
    this.onAddToPlaylist,
    this.onGoToAlbum,
    this.onGoToArtist,
    this.onCrossfadeSettings,
    this.onAudioQuality,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.only(top: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.outline
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'More Options',
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              children: [
                _buildOptionTile(
                  icon: 'playlist_add',
                  title: 'Add to Playlist',
                  onTap: onAddToPlaylist,
                ),
                _buildOptionTile(
                  icon: 'album',
                  title: 'Go to Album',
                  onTap: onGoToAlbum,
                ),
                _buildOptionTile(
                  icon: 'person',
                  title: 'Go to Artist',
                  onTap: onGoToArtist,
                ),
                Divider(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  height: 3.h,
                ),
                _buildOptionTile(
                  icon: 'tune',
                  title: 'Crossfade Settings',
                  onTap: onCrossfadeSettings,
                ),
                _buildOptionTile(
                  icon: 'high_quality',
                  title: 'Audio Quality',
                  onTap: onAudioQuality,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOptionTile({
    required String icon,
    required String title,
    VoidCallback? onTap,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        leading: Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color:
                AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: CustomIconWidget(
            iconName: icon,
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 20,
          ),
        ),
        title: Text(
          title,
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: CustomIconWidget(
          iconName: 'chevron_right',
          color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          size: 18,
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
