import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AlbumArtworkWidget extends StatefulWidget {
  final String imageUrl;
  final VoidCallback? onSwipeLeft;
  final VoidCallback? onSwipeRight;
  final VoidCallback? onSwipeUp;

  const AlbumArtworkWidget({
    Key? key,
    required this.imageUrl,
    this.onSwipeLeft,
    this.onSwipeRight,
    this.onSwipeUp,
  }) : super(key: key);

  @override
  State<AlbumArtworkWidget> createState() => _AlbumArtworkWidgetState();
}

class _AlbumArtworkWidgetState extends State<AlbumArtworkWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _parallaxController;
  late Animation<double> _parallaxAnimation;

  @override
  void initState() {
    super.initState();
    _parallaxController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    );
    _parallaxAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _parallaxController,
      curve: Curves.linear,
    ));
    _parallaxController.repeat();
  }

  @override
  void dispose() {
    _parallaxController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 50.h,
      child: GestureDetector(
        onHorizontalDragEnd: (details) {
          if (details.primaryVelocity != null) {
            if (details.primaryVelocity! > 0) {
              widget.onSwipeRight?.call();
            } else if (details.primaryVelocity! < 0) {
              widget.onSwipeLeft?.call();
            }
          }
        },
        onVerticalDragEnd: (details) {
          if (details.primaryVelocity != null && details.primaryVelocity! < 0) {
            widget.onSwipeUp?.call();
          }
        },
        child: Stack(
          children: [
            AnimatedBuilder(
              animation: _parallaxAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _parallaxAnimation.value * 10),
                  child: Container(
                    width: double.infinity,
                    height: 50.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.3),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: CustomImageWidget(
                        imageUrl: widget.imageUrl,
                        width: double.infinity,
                        height: 50.h,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              },
            ),
            Positioned(
              bottom: 16,
              right: 16,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: 'swipe_left',
                      color: Colors.white,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Swipe for controls',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: Colors.white,
                        fontSize: 10.sp,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
