import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/album_artwork_widget.dart';
import './widgets/more_options_bottom_sheet_widget.dart';
import './widgets/playback_controls_widget.dart';
import './widgets/progress_bar_widget.dart';
import './widgets/queue_bottom_sheet_widget.dart';
import './widgets/secondary_controls_widget.dart';
import './widgets/song_info_widget.dart';
import './widgets/volume_control_widget.dart';

class MusicPlayer extends StatefulWidget {
  const MusicPlayer({Key? key}) : super(key: key);

  @override
  State<MusicPlayer> createState() => _MusicPlayerState();
}

class _MusicPlayerState extends State<MusicPlayer>
    with TickerProviderStateMixin {
  // Mock current song data
  final Map<String, dynamic> currentSong = {
    "id": 1,
    "title": "Blinding Lights - Extended Version with Very Long Title",
    "artist": "The Weeknd",
    "album": "After Hours",
    "albumArt":
        "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "duration": Duration(minutes: 3, seconds: 42),
  };

  // Mock queue data
  final List<Map<String, dynamic>> queueItems = [
    {
      "id": 1,
      "title": "Blinding Lights",
      "artist": "The Weeknd",
      "albumArt":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
    {
      "id": 2,
      "title": "Save Your Tears",
      "artist": "The Weeknd",
      "albumArt":
          "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
    {
      "id": 3,
      "title": "Levitating",
      "artist": "Dua Lipa",
      "albumArt":
          "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
    {
      "id": 4,
      "title": "Good 4 U",
      "artist": "Olivia Rodrigo",
      "albumArt":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
  ];

  // Playback state
  bool _isPlaying = true;
  bool _isLiked = false;
  bool _isShuffleEnabled = false;
  bool _isRepeatEnabled = false;
  Duration _currentPosition = const Duration(minutes: 1, seconds: 23);
  double _volume = 0.7;
  int _currentQueueIndex = 0;

  // Animation controllers
  late AnimationController _playbackController;

  @override
  void initState() {
    super.initState();
    _playbackController = AnimationController(
      duration: currentSong["duration"] as Duration,
      vsync: this,
    );

    if (_isPlaying) {
      _playbackController.forward();
    }

    _playbackController.addListener(() {
      if (mounted) {
        setState(() {
          _currentPosition = Duration(
            milliseconds: (_playbackController.value *
                    (currentSong["duration"] as Duration).inMilliseconds)
                .round(),
          );
        });
      }
    });
  }

  @override
  void dispose() {
    _playbackController.dispose();
    super.dispose();
  }

  void _togglePlayPause() {
    setState(() {
      _isPlaying = !_isPlaying;
    });

    if (_isPlaying) {
      _playbackController.forward();
    } else {
      _playbackController.stop();
    }

    HapticFeedback.lightImpact();
  }

  void _toggleLike() {
    setState(() {
      _isLiked = !_isLiked;
    });
    HapticFeedback.lightImpact();
  }

  void _toggleShuffle() {
    setState(() {
      _isShuffleEnabled = !_isShuffleEnabled;
    });
    HapticFeedback.lightImpact();
  }

  void _toggleRepeat() {
    setState(() {
      _isRepeatEnabled = !_isRepeatEnabled;
    });
    HapticFeedback.lightImpact();
  }

  void _onSeek(Duration position) {
    setState(() {
      _currentPosition = position;
    });
    final progress = position.inMilliseconds /
        (currentSong["duration"] as Duration).inMilliseconds;
    _playbackController.value = progress;
  }

  void _onVolumeChanged(double volume) {
    setState(() {
      _volume = volume;
    });
  }

  void _previousTrack() {
    if (_currentQueueIndex > 0) {
      setState(() {
        _currentQueueIndex--;
        _currentPosition = Duration.zero;
      });
      _playbackController.reset();
      if (_isPlaying) {
        _playbackController.forward();
      }
    }
    HapticFeedback.lightImpact();
  }

  void _nextTrack() {
    if (_currentQueueIndex < queueItems.length - 1) {
      setState(() {
        _currentQueueIndex++;
        _currentPosition = Duration.zero;
      });
      _playbackController.reset();
      if (_isPlaying) {
        _playbackController.forward();
      }
    }
    HapticFeedback.lightImpact();
  }

  void _showShareSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 30.h,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              margin: EdgeInsets.only(top: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Text(
                'Share Song',
                style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Expanded(
              child: GridView.count(
                crossAxisCount: 4,
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                children: [
                  _buildShareOption('WhatsApp', 'message', () {}),
                  _buildShareOption('Instagram', 'camera_alt', () {}),
                  _buildShareOption('Twitter', 'share', () {}),
                  _buildShareOption('Copy Link', 'link', () {}),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShareOption(String title, String icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: CustomIconWidget(
              iconName: icon,
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 24,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              fontSize: 10.sp,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _showQueue() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => QueueBottomSheetWidget(
        queueItems: queueItems,
        currentIndex: _currentQueueIndex,
        onItemTap: (index) {
          setState(() {
            _currentQueueIndex = index;
            _currentPosition = Duration.zero;
          });
          _playbackController.reset();
          if (_isPlaying) {
            _playbackController.forward();
          }
          Navigator.pop(context);
        },
        onRemoveItem: (index) {
          setState(() {
            queueItems.removeAt(index);
            if (_currentQueueIndex >= index && _currentQueueIndex > 0) {
              _currentQueueIndex--;
            }
          });
        },
      ),
    );
  }

  void _showMoreOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => MoreOptionsBottomSheetWidget(
        onAddToPlaylist: () {
          Navigator.pop(context);
          Navigator.pushNamed(context, '/playlist-management');
        },
        onGoToAlbum: () {
          Navigator.pop(context);
          // Navigate to album view
        },
        onGoToArtist: () {
          Navigator.pop(context);
          // Navigate to artist profile
        },
        onCrossfadeSettings: () {
          Navigator.pop(context);
          // Show crossfade settings
        },
        onAudioQuality: () {
          Navigator.pop(context);
          // Show audio quality settings
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface
                  .withValues(alpha: 0.8),
              borderRadius: BorderRadius.circular(12),
            ),
            child: CustomIconWidget(
              iconName: 'keyboard_arrow_down',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
        ),
        actions: [
          GestureDetector(
            onTap: _showMoreOptions,
            child: Container(
              margin: EdgeInsets.all(2.w),
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface
                    .withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: CustomIconWidget(
                iconName: 'more_vert',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 2.h),
              AlbumArtworkWidget(
                imageUrl: currentSong["albumArt"] as String,
                onSwipeLeft: _nextTrack,
                onSwipeRight: _previousTrack,
                onSwipeUp: () {
                  // Show lyrics overlay
                },
              ),
              SizedBox(height: 3.h),
              SongInfoWidget(
                title: currentSong["title"] as String,
                artist: currentSong["artist"] as String,
                album: currentSong["album"] as String,
                isLiked: _isLiked,
                onLikeToggle: _toggleLike,
              ),
              SizedBox(height: 2.h),
              ProgressBarWidget(
                currentPosition: _currentPosition,
                totalDuration: currentSong["duration"] as Duration,
                onSeek: _onSeek,
              ),
              SizedBox(height: 3.h),
              PlaybackControlsWidget(
                isPlaying: _isPlaying,
                isShuffleEnabled: _isShuffleEnabled,
                isRepeatEnabled: _isRepeatEnabled,
                onPlayPause: _togglePlayPause,
                onPrevious: _previousTrack,
                onNext: _nextTrack,
                onShuffle: _toggleShuffle,
                onRepeat: _toggleRepeat,
              ),
              SizedBox(height: 2.h),
              SecondaryControlsWidget(
                onShare: _showShareSheet,
                onQueue: _showQueue,
                onMore: _showMoreOptions,
              ),
              SizedBox(height: 2.h),
              VolumeControlWidget(
                volume: _volume,
                onVolumeChanged: _onVolumeChanged,
              ),
              SizedBox(height: 4.h),
            ],
          ),
        ),
      ),
    );
  }
}
