import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MessageBubbleWidget extends StatelessWidget {
  final Map<String, dynamic> message;
  final bool isMe;

  const MessageBubbleWidget({
    Key? key,
    required this.message,
    required this.isMe,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final messageType = message['type'] as String? ?? 'text';

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            CircleAvatar(
              radius: 2.5.w,
              child: CustomImageWidget(
                imageUrl: message['senderAvatar'] as String? ??
                    'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
                width: 5.w,
                height: 5.w,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(width: 2.w),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: 70.w),
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
              decoration: BoxDecoration(
                color: isMe
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.surface
                        .withValues(alpha: 0.8),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(4.w),
                  topRight: Radius.circular(4.w),
                  bottomLeft:
                      isMe ? Radius.circular(4.w) : Radius.circular(1.w),
                  bottomRight:
                      isMe ? Radius.circular(1.w) : Radius.circular(4.w),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildMessageContent(context, messageType),
                  SizedBox(height: 0.5.h),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _formatTime(message['timestamp'] as DateTime? ??
                            DateTime.now()),
                        style:
                            AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                          color: isMe
                              ? Colors.white.withValues(alpha: 0.8)
                              : AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      if (isMe) ...[
                        SizedBox(width: 1.w),
                        _buildMessageStatus(),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (isMe) SizedBox(width: 2.w),
        ],
      ),
    );
  }

  Widget _buildMessageContent(BuildContext context, String messageType) {
    switch (messageType) {
      case 'music':
        return _buildMusicMessage(context);
      case 'voice':
        return _buildVoiceMessage(context);
      case 'playlist':
        return _buildPlaylistMessage(context);
      default:
        return _buildTextMessage(context);
    }
  }

  Widget _buildTextMessage(BuildContext context) {
    return Text(
      message['content'] as String? ?? '',
      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
        color: isMe ? Colors.white : AppTheme.lightTheme.colorScheme.onSurface,
      ),
    );
  }

  Widget _buildMusicMessage(BuildContext context) {
    final musicData = message['musicData'] as Map<String, dynamic>? ?? {};

    return Container(
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: isMe
            ? Colors.white.withValues(alpha: 0.1)
            : AppTheme.lightTheme.colorScheme.primaryContainer
                .withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(2.w),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(1.5.w),
            child: CustomImageWidget(
              imageUrl: musicData['artwork'] as String? ??
                  'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300',
              width: 12.w,
              height: 12.w,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  musicData['title'] as String? ?? 'Unknown Song',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    color: isMe
                        ? Colors.white
                        : AppTheme.lightTheme.colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  musicData['artist'] as String? ?? 'Unknown Artist',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: isMe
                        ? Colors.white.withValues(alpha: 0.8)
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _playMusic(musicData),
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isMe
                    ? Colors.white.withValues(alpha: 0.2)
                    : AppTheme.lightTheme.primaryColor.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: 'play_arrow',
                color: isMe ? Colors.white : AppTheme.lightTheme.primaryColor,
                size: 5.w,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoiceMessage(BuildContext context) {
    final duration = message['duration'] as int? ?? 30;

    return Container(
      padding: EdgeInsets.all(2.w),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _playVoiceMessage(),
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isMe
                    ? Colors.white.withValues(alpha: 0.2)
                    : AppTheme.lightTheme.primaryColor.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: 'play_arrow',
                color: isMe ? Colors.white : AppTheme.lightTheme.primaryColor,
                size: 4.w,
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Container(
              height: 1.h,
              child: Row(
                children: List.generate(20, (index) {
                  return Container(
                    width: 0.5.w,
                    height: (index % 3 + 1) * 0.3.h,
                    margin: EdgeInsets.symmetric(horizontal: 0.2.w),
                    decoration: BoxDecoration(
                      color: isMe
                          ? Colors.white.withValues(alpha: 0.6)
                          : AppTheme.lightTheme.primaryColor
                              .withValues(alpha: 0.6),
                      borderRadius: BorderRadius.circular(0.5.w),
                    ),
                  );
                }),
              ),
            ),
          ),
          SizedBox(width: 2.w),
          Text(
            '${duration}s',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: isMe
                  ? Colors.white.withValues(alpha: 0.8)
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaylistMessage(BuildContext context) {
    final playlistData = message['playlistData'] as Map<String, dynamic>? ?? {};
    final songs =
        (playlistData['songs'] as List?)?.cast<Map<String, dynamic>>() ?? [];

    return Container(
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: isMe
            ? Colors.white.withValues(alpha: 0.1)
            : AppTheme.lightTheme.colorScheme.primaryContainer
                .withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(2.w),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(1.5.w),
                child: CustomImageWidget(
                  imageUrl: playlistData['artwork'] as String? ??
                      'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300',
                  width: 12.w,
                  height: 12.w,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      playlistData['name'] as String? ?? 'Shared Playlist',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        color: isMe
                            ? Colors.white
                            : AppTheme.lightTheme.colorScheme.onSurface,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${songs.length} songs',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: isMe
                            ? Colors.white.withValues(alpha: 0.8)
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          GestureDetector(
            onTap: () => _openPlaylist(playlistData),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 1.5.h),
              decoration: BoxDecoration(
                color: isMe
                    ? Colors.white.withValues(alpha: 0.2)
                    : AppTheme.lightTheme.primaryColor.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(1.5.w),
              ),
              child: Center(
                child: Text(
                  'View Playlist',
                  style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                    color:
                        isMe ? Colors.white : AppTheme.lightTheme.primaryColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageStatus() {
    final status = message['status'] as String? ?? 'sent';
    Color statusColor = Colors.white.withValues(alpha: 0.6);

    switch (status) {
      case 'delivered':
        statusColor = Colors.white.withValues(alpha: 0.8);
        break;
      case 'read':
        statusColor = AppTheme.lightTheme.colorScheme.secondary;
        break;
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        CustomIconWidget(
          iconName: status == 'sent' ? 'check' : 'done_all',
          color: statusColor,
          size: 3.w,
        ),
      ],
    );
  }

  String _formatTime(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${timestamp.month}/${timestamp.day}';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'now';
    }
  }

  void _playMusic(Map<String, dynamic> musicData) {
    // Navigate to music player with the shared song
    print('Playing music: ${musicData['title']}');
  }

  void _playVoiceMessage() {
    // Play voice message
    print('Playing voice message');
  }

  void _openPlaylist(Map<String, dynamic> playlistData) {
    // Navigate to playlist view
    print('Opening playlist: ${playlistData['name']}');
  }
}
