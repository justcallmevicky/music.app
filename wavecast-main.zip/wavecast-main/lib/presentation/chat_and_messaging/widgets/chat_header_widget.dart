import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ChatHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> contact;
  final VoidCallback onBackPressed;
  final VoidCallback? onVideoCall;
  final VoidCallback? onVoiceCall;
  final VoidCallback? onMoreOptions;

  const ChatHeaderWidget({
    Key? key,
    required this.contact,
    required this.onBackPressed,
    this.onVideoCall,
    this.onVoiceCall,
    this.onMoreOptions,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isOnline = contact['isOnline'] as bool? ?? false;
    final lastSeen = contact['lastSeen'] as DateTime?;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            GestureDetector(
              onTap: onBackPressed,
              child: Container(
                padding: EdgeInsets.all(2.w),
                child: CustomIconWidget(
                  iconName: 'arrow_back',
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                  size: 6.w,
                ),
              ),
            ),
            SizedBox(width: 3.w),
            _buildContactInfo(isOnline, lastSeen),
            Spacer(),
            if (onVideoCall != null)
              _buildActionButton('videocam', onVideoCall!),
            SizedBox(width: 2.w),
            if (onVoiceCall != null) _buildActionButton('call', onVoiceCall!),
            SizedBox(width: 2.w),
            if (onMoreOptions != null)
              _buildActionButton('more_vert', onMoreOptions!),
          ],
        ),
      ),
    );
  }

  Widget _buildContactInfo(bool isOnline, DateTime? lastSeen) {
    return Expanded(
      child: Row(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 5.w,
                child: CustomImageWidget(
                  imageUrl: contact['avatar'] as String? ??
                      'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
                  width: 10.w,
                  height: 10.w,
                  fit: BoxFit.cover,
                ),
              ),
              if (isOnline)
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 3.w,
                    height: 3.w,
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.surface,
                        width: 1,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        contact['name'] as String? ?? 'Unknown User',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (contact['isVerified'] as bool? ?? false) ...[
                      SizedBox(width: 1.w),
                      CustomIconWidget(
                        iconName: 'verified',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 4.w,
                      ),
                    ],
                  ],
                ),
                SizedBox(height: 0.5.h),
                Text(
                  _getStatusText(isOnline, lastSeen),
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: isOnline
                        ? AppTheme.lightTheme.primaryColor
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(String iconName, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(2.5.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.primaryContainer
              .withValues(alpha: 0.3),
          shape: BoxShape.circle,
        ),
        child: CustomIconWidget(
          iconName: iconName,
          color: AppTheme.lightTheme.primaryColor,
          size: 5.w,
        ),
      ),
    );
  }

  String _getStatusText(bool isOnline, DateTime? lastSeen) {
    if (isOnline) {
      return 'Online';
    } else if (lastSeen != null) {
      final now = DateTime.now();
      final difference = now.difference(lastSeen);

      if (difference.inMinutes < 1) {
        return 'Last seen just now';
      } else if (difference.inHours < 1) {
        return 'Last seen ${difference.inMinutes}m ago';
      } else if (difference.inDays < 1) {
        return 'Last seen ${difference.inHours}h ago';
      } else if (difference.inDays < 7) {
        return 'Last seen ${difference.inDays}d ago';
      } else {
        return 'Last seen ${lastSeen.month}/${lastSeen.day}/${lastSeen.year}';
      }
    } else {
      return 'Offline';
    }
  }
}
