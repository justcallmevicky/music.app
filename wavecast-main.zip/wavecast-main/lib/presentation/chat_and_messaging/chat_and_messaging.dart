import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/chat_header_widget.dart';
import './widgets/chat_input_widget.dart';
import './widgets/message_bubble_widget.dart';
import './widgets/typing_indicator_widget.dart';

class ChatAndMessaging extends StatefulWidget {
  const ChatAndMessaging({Key? key}) : super(key: key);

  @override
  State<ChatAndMessaging> createState() => _ChatAndMessagingState();
}

class _ChatAndMessagingState extends State<ChatAndMessaging> {
  final ScrollController _scrollController = ScrollController();
  bool _isRecording = false;
  bool _isTyping = false;
  String _currentUserId = 'user1';

  // Mock data for the current contact
  final Map<String, dynamic> _currentContact = {
    'id': 'user2',
    'name': 'Sarah Johnson',
    'avatar':
        'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
    'isOnline': true,
    'lastSeen': DateTime.now().subtract(Duration(minutes: 5)),
    'isVerified': true,
  };

  // Mock messages data
  final List<Map<String, dynamic>> _messages = [
    {
      'id': '1',
      'senderId': 'user2',
      'senderName': 'Sarah Johnson',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Hey! Have you heard the new album by Arctic Monkeys?',
      'type': 'text',
      'timestamp': DateTime.now().subtract(Duration(hours: 2)),
      'status': 'read',
    },
    {
      'id': '2',
      'senderId': 'user1',
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Not yet! Is it good?',
      'type': 'text',
      'timestamp': DateTime.now().subtract(Duration(hours: 2, minutes: 5)),
      'status': 'read',
    },
    {
      'id': '3',
      'senderId': 'user2',
      'senderName': 'Sarah Johnson',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Check this out!',
      'type': 'music',
      'musicData': {
        'title': 'Do I Wanna Know?',
        'artist': 'Arctic Monkeys',
        'artwork':
            'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300',
        'duration': 263,
        'url': 'https://example.com/song.mp3',
      },
      'timestamp': DateTime.now().subtract(Duration(hours: 1, minutes: 45)),
      'status': 'read',
    },
    {
      'id': '4',
      'senderId': 'user1',
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Amazing track! 🔥',
      'type': 'text',
      'timestamp': DateTime.now().subtract(Duration(hours: 1, minutes: 40)),
      'status': 'read',
    },
    {
      'id': '5',
      'senderId': 'user2',
      'senderName': 'Sarah Johnson',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Voice message about the concert',
      'type': 'voice',
      'duration': 45,
      'timestamp': DateTime.now().subtract(Duration(hours: 1, minutes: 30)),
      'status': 'read',
    },
    {
      'id': '6',
      'senderId': 'user1',
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Here\'s my favorite playlist for road trips',
      'type': 'playlist',
      'playlistData': {
        'id': 'playlist1',
        'name': 'Road Trip Vibes',
        'artwork':
            'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300',
        'songs': [
          {'title': 'Bohemian Rhapsody', 'artist': 'Queen'},
          {'title': 'Hotel California', 'artist': 'Eagles'},
          {'title': 'Sweet Child O\' Mine', 'artist': 'Guns N\' Roses'},
          {'title': 'Don\'t Stop Believin\'', 'artist': 'Journey'},
        ],
        'totalDuration': 3600,
      },
      'timestamp': DateTime.now().subtract(Duration(minutes: 45)),
      'status': 'delivered',
    },
    {
      'id': '7',
      'senderId': 'user2',
      'senderName': 'Sarah Johnson',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Perfect for our weekend trip! Adding it to my library 📚',
      'type': 'text',
      'timestamp': DateTime.now().subtract(Duration(minutes: 30)),
      'status': 'read',
    },
    {
      'id': '8',
      'senderId': 'user1',
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Can\'t wait! It\'s going to be epic 🚗🎵',
      'type': 'text',
      'timestamp': DateTime.now().subtract(Duration(minutes: 15)),
      'status': 'sent',
    },
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });

    // Simulate typing indicator
    Future.delayed(Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _isTyping = true;
        });

        Future.delayed(Duration(seconds: 4), () {
          if (mounted) {
            setState(() {
              _isTyping = false;
            });
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _sendMessage(String content, String type) {
    final newMessage = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'senderId': _currentUserId,
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': content,
      'type': type,
      'timestamp': DateTime.now(),
      'status': 'sent',
    };

    setState(() {
      _messages.add(newMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });

    // Simulate message status updates
    Future.delayed(Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          newMessage['status'] = 'delivered';
        });
      }
    });

    Future.delayed(Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          newMessage['status'] = 'read';
        });
      }
    });
  }

  void _attachMusic() {
    // Simulate music attachment
    final musicMessage = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'senderId': _currentUserId,
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Shared a song',
      'type': 'music',
      'musicData': {
        'title': 'Blinding Lights',
        'artist': 'The Weeknd',
        'artwork':
            'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300',
        'duration': 200,
        'url': 'https://example.com/blinding-lights.mp3',
      },
      'timestamp': DateTime.now(),
      'status': 'sent',
    };

    setState(() {
      _messages.add(musicMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  void _startVoiceRecording() {
    setState(() {
      _isRecording = true;
    });
    print('Started voice recording');
  }

  void _stopVoiceRecording() {
    setState(() {
      _isRecording = false;
    });

    // Simulate voice message creation
    final voiceMessage = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'senderId': _currentUserId,
      'senderName': 'You',
      'senderAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'content': 'Voice message',
      'type': 'voice',
      'duration': 30,
      'timestamp': DateTime.now(),
      'status': 'sent',
    };

    setState(() {
      _messages.add(voiceMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });

    print('Stopped voice recording');
  }

  void _onVideoCall() {
    print('Starting video call with ${_currentContact['name']}');
    // Navigate to video call screen or show call interface
  }

  void _onVoiceCall() {
    print('Starting voice call with ${_currentContact['name']}');
    // Navigate to voice call screen or show call interface
  }

  void _onMoreOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(4.w)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.dividerColor,
                borderRadius: BorderRadius.circular(1.w),
              ),
            ),
            SizedBox(height: 3.h),
            _buildOptionTile('View Profile', 'person', () {
              Navigator.pop(context);
              print('View profile');
            }),
            _buildOptionTile('Media & Files', 'photo_library', () {
              Navigator.pop(context);
              print('View media');
            }),
            _buildOptionTile('Search Messages', 'search', () {
              Navigator.pop(context);
              print('Search messages');
            }),
            _buildOptionTile('Clear Chat', 'delete_sweep', () {
              Navigator.pop(context);
              _showClearChatDialog();
            }),
            _buildOptionTile('Block User', 'block', () {
              Navigator.pop(context);
              _showBlockUserDialog();
            }),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionTile(String title, String icon, VoidCallback onTap) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: AppTheme.lightTheme.colorScheme.onSurface,
        size: 6.w,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge,
      ),
      onTap: onTap,
      contentPadding: EdgeInsets.symmetric(horizontal: 2.w),
    );
  }

  void _showClearChatDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Clear Chat'),
        content: Text(
            'Are you sure you want to clear all messages? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _messages.clear();
              });
            },
            child: Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _showBlockUserDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Block User'),
        content: Text(
            'Are you sure you want to block ${_currentContact['name']}? You won\'t receive messages from them.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // Go back to previous screen
            },
            child: Text('Block'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Column(
        children: [
          ChatHeaderWidget(
            contact: _currentContact,
            onBackPressed: () => Navigator.pop(context),
            onVideoCall: _onVideoCall,
            onVoiceCall: _onVoiceCall,
            onMoreOptions: _onMoreOptions,
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.lightTheme.scaffoldBackgroundColor,
                    AppTheme.lightTheme.scaffoldBackgroundColor
                        .withValues(alpha: 0.95),
                  ],
                ),
              ),
              child: ListView.builder(
                controller: _scrollController,
                padding: EdgeInsets.symmetric(vertical: 2.h),
                itemCount: _messages.length + (_isTyping ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == _messages.length && _isTyping) {
                    return TypingIndicatorWidget(
                      userName: _currentContact['name'] as String,
                      isVisible: _isTyping,
                    );
                  }

                  final message = _messages[index];
                  final isMe = message['senderId'] == _currentUserId;

                  return GestureDetector(
                    onLongPress: () => _showMessageOptions(message),
                    child: MessageBubbleWidget(
                      message: message,
                      isMe: isMe,
                    ),
                  );
                },
              ),
            ),
          ),
          ChatInputWidget(
            onSendMessage: _sendMessage,
            onAttachMusic: _attachMusic,
            onStartVoiceRecording: _startVoiceRecording,
            onStopVoiceRecording: _stopVoiceRecording,
            isRecording: _isRecording,
          ),
        ],
      ),
    );
  }

  void _showMessageOptions(Map<String, dynamic> message) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(4.w)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.dividerColor,
                borderRadius: BorderRadius.circular(1.w),
              ),
            ),
            SizedBox(height: 3.h),
            _buildMessageOption('Copy', 'content_copy', () {
              Navigator.pop(context);
              print('Copy message: ${message['content']}');
            }),
            _buildMessageOption('Forward', 'forward', () {
              Navigator.pop(context);
              print('Forward message');
            }),
            _buildMessageOption('React', 'emoji_emotions', () {
              Navigator.pop(context);
              _showReactionPicker(message);
            }),
            if (message['senderId'] == _currentUserId)
              _buildMessageOption('Delete', 'delete', () {
                Navigator.pop(context);
                _deleteMessage(message);
              }),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageOption(String title, String icon, VoidCallback onTap) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: AppTheme.lightTheme.colorScheme.onSurface,
        size: 6.w,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge,
      ),
      onTap: onTap,
      contentPadding: EdgeInsets.symmetric(horizontal: 2.w),
    );
  }

  void _showReactionPicker(Map<String, dynamic> message) {
    final reactions = ['❤️', '😂', '😮', '😢', '😡', '👍', '👎'];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(4.w)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'React to message',
              style: AppTheme.lightTheme.textTheme.titleMedium,
            ),
            SizedBox(height: 3.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: reactions.map((reaction) {
                return GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    print('Reacted with $reaction');
                  },
                  child: Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primaryContainer
                          .withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      reaction,
                      style: TextStyle(fontSize: 6.w),
                    ),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  void _deleteMessage(Map<String, dynamic> message) {
    setState(() {
      _messages.removeWhere((msg) => msg['id'] == message['id']);
    });
  }
}
