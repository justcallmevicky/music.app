import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../services/auth_service.dart';
import './social_login_button.dart';

class SocialLoginSection extends StatefulWidget {
  const SocialLoginSection({Key? key}) : super(key: key);

  @override
  State<SocialLoginSection> createState() => _SocialLoginSectionState();
}

class _SocialLoginSectionState extends State<SocialLoginSection> {
  final AuthService _authService = AuthService();
  bool _isGoogleLoading = false;

  void _handleGoogleSignIn() async {
    setState(() {
      _isGoogleLoading = true;
    });

    try {
      final success = await _authService.signInWithGoogle();

      if (!mounted) return;

      if (success) {
        // Navigation will be handled by auth state listener in parent
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Successfully signed in with Google!'),
            backgroundColor: Colors.green));
      }
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(error.toString().replaceAll('Exception: ', '')),
          backgroundColor: Colors.red));
    } finally {
      if (mounted) {
        setState(() {
          _isGoogleLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // Divider with "OR" text
      Row(children: [
        Expanded(
            child:
                Divider(color: Theme.of(context).dividerColor, thickness: 1)),
        Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Text('OR',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).textTheme.bodySmall?.color,
                    fontWeight: FontWeight.w500))),
        Expanded(
            child:
                Divider(color: Theme.of(context).dividerColor, thickness: 1)),
      ]),

      SizedBox(height: 3.h),

      // Social Login Buttons
      SocialLoginButton(
          onPressed: _isGoogleLoading ? null : _handleGoogleSignIn,
          iconName: 'google',
          label: 'Continue with Google',
          backgroundColor: Colors.white,
          textColor: Colors.black87),

      SizedBox(height: 2.h),

      // Apple Sign In (iOS only or for preview)
      SocialLoginButton(
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('Apple Sign-In coming soon!'),
                backgroundColor: Colors.blue));
          },
          iconName: 'apple',
          label: 'Continue with Apple',
          backgroundColor: Colors.black,
          textColor: Colors.white),

      SizedBox(height: 2.h),

      // Facebook Sign In
      SocialLoginButton(
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('Facebook Sign-In coming soon!'),
                backgroundColor: Colors.blue));
          },
          iconName: 'facebook',
          label: 'Continue with Facebook',
          backgroundColor: Color(0xFF1877F2),
          textColor: Colors.white),
    ]);
  }
}