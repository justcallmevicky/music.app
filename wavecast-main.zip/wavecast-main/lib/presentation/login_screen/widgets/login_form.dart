import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../routes/app_routes.dart';
import '../../../services/auth_service.dart';
import './custom_text_field.dart';

class LoginForm extends StatefulWidget {
  const LoginForm({Key? key}) : super(key: key);

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final AuthService _authService = AuthService();

  bool _isLoading = false;
  bool _rememberMe = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _handleLogin() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await _authService.signIn(
          email: _emailController.text.trim(),
          password: _passwordController.text);

      if (!mounted) return;

      if (response.user != null) {
        Navigator.pushReplacementNamed(context, AppRoutes.homeDashboard);
      }
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(error.toString().replaceAll('Exception: ', '')),
          backgroundColor: Colors.red));
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _formKey,
        child: Column(children: [
          CustomTextField(
              controller: _emailController,
              hint: 'Enter your email or username',
              label: 'Email/Username',
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                if (value?.isEmpty == true) {
                  return 'Please enter your email or username';
                }
                return null;
              }),

          SizedBox(height: 3.h),

          CustomTextField(
              controller: _passwordController,
              hint: 'Enter your password',
              label: 'Password',
              isPassword: true,
              validator: (value) {
                if (value?.isEmpty == true) {
                  return 'Please enter your password';
                }
                if (value!.length < 6) {
                  return 'Password must be at least 6 characters';
                }
                return null;
              }),

          SizedBox(height: 2.h),

          // Remember Me and Forgot Password Row
          Row(children: [
            Expanded(
                child: Row(children: [
              Checkbox(
                  value: _rememberMe,
                  onChanged: (value) {
                    setState(() {
                      _rememberMe = value ?? false;
                    });
                  }),
              Text('Remember me', style: Theme.of(context).textTheme.bodySmall),
            ])),
            TextButton(
                onPressed: () {
                  _showForgotPasswordDialog();
                },
                child: Text('Forgot Password?',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w600))),
          ]),

          SizedBox(height: 3.h),

          // Login Button
          SizedBox(
              width: double.infinity,
              height: 6.h,
              child: ElevatedButton(
                  onPressed: _isLoading ? null : _handleLogin,
                  child: _isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text('Sign In',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w600)))),
        ]));
  }

  void _showForgotPasswordDialog() {
    final TextEditingController emailController = TextEditingController();

    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text('Reset Password'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                Text(
                    'Enter your email address and we will send you a link to reset your password.',
                    style: Theme.of(context).textTheme.bodyMedium),
                SizedBox(height: 2.h),
                TextField(
                    controller: emailController,
                    decoration: InputDecoration(
                        labelText: 'Email',
                        hintText: 'Enter your email',
                        prefixIcon: Icon(Icons.email_outlined)),
                    keyboardType: TextInputType.emailAddress),
              ]),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      emailController.dispose();
                    },
                    child: Text('Cancel')),
                ElevatedButton(
                    onPressed: () async {
                      if (emailController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text('Please enter your email'),
                            backgroundColor: Colors.red));
                        return;
                      }

                      try {
                        await _authService
                            .resetPassword(emailController.text.trim());

                        if (!mounted) return;
                        Navigator.of(context).pop();

                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content:
                                Text('Password reset link sent to your email!'),
                            backgroundColor: Colors.green));
                      } catch (error) {
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text(
                                error.toString().replaceAll('Exception: ', '')),
                            backgroundColor: Colors.red));
                      } finally {
                        emailController.dispose();
                      }
                    },
                    child: Text('Send Link')),
              ]);
        });
  }
}