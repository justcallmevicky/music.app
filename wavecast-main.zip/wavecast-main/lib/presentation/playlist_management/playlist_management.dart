import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/add_songs_overlay_widget.dart';
import './widgets/bottom_toolbar_widget.dart';
import './widgets/empty_playlist_widget.dart';
import './widgets/playlist_description_widget.dart';
import './widgets/playlist_header_widget.dart';
import './widgets/privacy_toggle_widget.dart';
import './widgets/track_list_item_widget.dart';

class PlaylistManagement extends StatefulWidget {
  const PlaylistManagement({super.key});

  @override
  State<PlaylistManagement> createState() => _PlaylistManagementState();
}

class _PlaylistManagementState extends State<PlaylistManagement> {
  String _playlistTitle = "My Awesome Playlist";
  String _playlistDescription =
      "A collection of my favorite songs for every mood and moment.";
  PlaylistPrivacy _currentPrivacy = PlaylistPrivacy.public;
  bool _showAddSongsOverlay = false;

  List<Map<String, dynamic>> _playlistTracks = [
    {
      "id": 1,
      "title": "Blinding Lights",
      "artist": "The Weeknd",
      "duration": 200,
      "artwork":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "addedDate": "2025-07-20"
    },
    {
      "id": 2,
      "title": "Watermelon Sugar",
      "artist": "Harry Styles",
      "duration": 174,
      "artwork":
          "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop",
      "addedDate": "2025-07-19"
    },
    {
      "id": 3,
      "title": "Levitating",
      "artist": "Dua Lipa",
      "duration": 203,
      "artwork":
          "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
      "addedDate": "2025-07-18"
    },
    {
      "id": 4,
      "title": "Good 4 U",
      "artist": "Olivia Rodrigo",
      "duration": 178,
      "artwork":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "addedDate": "2025-07-17"
    },
  ];

  void _onTitleChanged(String newTitle) {
    setState(() {
      _playlistTitle = newTitle;
    });
    Fluttertoast.showToast(
      msg: "Playlist title updated",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onDescriptionChanged(String newDescription) {
    setState(() {
      _playlistDescription = newDescription;
    });
    Fluttertoast.showToast(
      msg: "Description updated",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onPrivacyChanged(PlaylistPrivacy privacy) {
    setState(() {
      _currentPrivacy = privacy;
    });
    String privacyText = privacy == PlaylistPrivacy.public
        ? "Public"
        : privacy == PlaylistPrivacy.private
            ? "Private"
            : "Friends Only";
    Fluttertoast.showToast(
      msg: "Playlist is now $privacyText",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onCoverTap() {
    Fluttertoast.showToast(
      msg: "Cover photo feature coming soon",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onTrackTap(Map<String, dynamic> track) {
    Navigator.pushNamed(context, '/music-player');
  }

  void _onTrackMoreTap(Map<String, dynamic> track) {
    _showTrackOptionsBottomSheet(track);
  }

  void _onDeleteTrack(Map<String, dynamic> track) {
    _showDeleteConfirmationDialog(track);
  }

  void _onMoveToTop(Map<String, dynamic> track) {
    setState(() {
      _playlistTracks.removeWhere((t) => t['id'] == track['id']);
      _playlistTracks.insert(0, track);
    });
    Fluttertoast.showToast(
      msg: "Moved to top",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onAddToQueue(Map<String, dynamic> track) {
    Fluttertoast.showToast(
      msg: "Added to queue",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onAddSongs() {
    setState(() {
      _showAddSongsOverlay = true;
    });
  }

  void _onSongsSelected(List<Map<String, dynamic>> selectedSongs) {
    setState(() {
      for (var song in selectedSongs) {
        if (!_playlistTracks.any((track) => track['id'] == song['id'])) {
          _playlistTracks.add({
            ...song,
            'addedDate': DateTime.now().toString().split(' ')[0],
          });
        }
      }
    });
    Fluttertoast.showToast(
      msg: "Added ${selectedSongs.length} song(s)",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onShufflePlay() {
    if (_playlistTracks.isNotEmpty) {
      Navigator.pushNamed(context, '/music-player');
      Fluttertoast.showToast(
        msg: "Shuffle play started",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
    }
  }

  void _onShare() {
    _showShareBottomSheet();
  }

  void _showTrackOptionsBottomSheet(Map<String, dynamic> track) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.textSecondaryLight,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CustomImageWidget(
                    imageUrl: track['artwork'] as String,
                    width: 15.w,
                    height: 15.w,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track['title'] as String,
                        style: AppTheme.lightTheme.textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        track['artist'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.textSecondaryLight,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 3.h),
            _buildBottomSheetOption(
              'Play Next',
              'queue_music',
              () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Added to play next");
              },
            ),
            _buildBottomSheetOption(
              'Move to Top',
              'keyboard_arrow_up',
              () {
                Navigator.pop(context);
                _onMoveToTop(track);
              },
            ),
            _buildBottomSheetOption(
              'Share Song',
              'share',
              () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Sharing song...");
              },
            ),
            _buildBottomSheetOption(
              'Remove from Playlist',
              'delete',
              () {
                Navigator.pop(context);
                _onDeleteTrack(track);
              },
              isDestructive: true,
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmationDialog(Map<String, dynamic> track) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove Song'),
        content: Text(
          'Are you sure you want to remove "${track['title']}" from this playlist?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _playlistTracks.removeWhere((t) => t['id'] == track['id']);
              });
              Fluttertoast.showToast(
                msg: "Song removed from playlist",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.BOTTOM,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorLight,
            ),
            child: Text(
              'Remove',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showShareBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.textSecondaryLight,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Share Playlist',
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            _buildBottomSheetOption(
              'Copy Link',
              'link',
              () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Link copied to clipboard");
              },
            ),
            _buildBottomSheetOption(
              'Share to Social Media',
              'share',
              () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Opening share options...");
              },
            ),
            _buildBottomSheetOption(
              'Invite Collaborators',
              'group_add',
              () {
                Navigator.pop(context);
                Fluttertoast.showToast(
                    msg: "Collaboration feature coming soon");
              },
            ),
            _buildBottomSheetOption(
              'Send via Message',
              'message',
              () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/chat-and-messaging');
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomSheetOption(
    String title,
    String iconName,
    VoidCallback onTap, {
    bool isDestructive = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 2.h),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: isDestructive
                  ? AppTheme.errorLight
                  : AppTheme.textPrimaryLight,
              size: 6.w,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: isDestructive
                    ? AppTheme.errorLight
                    : AppTheme.textPrimaryLight,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Playlist'),
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: EdgeInsets.all(3.w),
            child: CustomIconWidget(
              iconName: 'arrow_back',
              color: AppTheme.textPrimaryLight,
              size: 6.w,
            ),
          ),
        ),
        actions: [
          GestureDetector(
            onTap: () {
              Navigator.pushNamed(context, '/search-and-browse');
            },
            child: Container(
              padding: EdgeInsets.all(3.w),
              child: CustomIconWidget(
                iconName: 'search',
                color: AppTheme.textPrimaryLight,
                size: 6.w,
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Playlist Header
                      PlaylistHeaderWidget(
                        playlistTitle: _playlistTitle,
                        creatorName: "You",
                        coverImageUrl:
                            "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop",
                        onTitleChanged: _onTitleChanged,
                        onCoverTap: _onCoverTap,
                      ),

                      // Description
                      PlaylistDescriptionWidget(
                        description: _playlistDescription,
                        onDescriptionChanged: _onDescriptionChanged,
                      ),

                      SizedBox(height: 2.h),

                      // Privacy Settings
                      PrivacyToggleWidget(
                        currentPrivacy: _currentPrivacy,
                        onPrivacyChanged: _onPrivacyChanged,
                      ),

                      SizedBox(height: 3.h),

                      // Track List or Empty State
                      _playlistTracks.isEmpty
                          ? EmptyPlaylistWidget(
                              onAddSongs: _onAddSongs,
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 4.w),
                                  child: Row(
                                    children: [
                                      Text(
                                        'Songs',
                                        style: AppTheme
                                            .lightTheme.textTheme.titleLarge
                                            ?.copyWith(
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      SizedBox(width: 2.w),
                                      Text(
                                        '(${_playlistTracks.length})',
                                        style: AppTheme
                                            .lightTheme.textTheme.titleMedium
                                            ?.copyWith(
                                          color: AppTheme.textSecondaryLight,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 2.h),
                                ReorderableListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: _playlistTracks.length,
                                  onReorder: (oldIndex, newIndex) {
                                    setState(() {
                                      if (newIndex > oldIndex) {
                                        newIndex -= 1;
                                      }
                                      final item =
                                          _playlistTracks.removeAt(oldIndex);
                                      _playlistTracks.insert(newIndex, item);
                                    });
                                    Fluttertoast.showToast(
                                      msg: "Song reordered",
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                    );
                                  },
                                  itemBuilder: (context, index) {
                                    final track = _playlistTracks[index];
                                    return TrackListItemWidget(
                                      key: ValueKey(track['id']),
                                      track: track,
                                      onTap: () => _onTrackTap(track),
                                      onMoreTap: () => _onTrackMoreTap(track),
                                      onDeleteTap: () => _onDeleteTrack(track),
                                      onMoveToTop: () => _onMoveToTop(track),
                                      onAddToQueue: () => _onAddToQueue(track),
                                    );
                                  },
                                ),
                              ],
                            ),

                      SizedBox(height: 12.h), // Space for bottom toolbar
                    ],
                  ),
                ),
              ),

              // Bottom Toolbar
              BottomToolbarWidget(
                onAddSongs: _onAddSongs,
                onShufflePlay: _onShufflePlay,
                onShare: _onShare,
                hasTrack: _playlistTracks.isNotEmpty,
              ),
            ],
          ),

          // Add Songs Overlay
          if (_showAddSongsOverlay)
            Positioned.fill(
              child: Container(
                color: Colors.black.withValues(alpha: 0.5),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: AddSongsOverlayWidget(
                    onSongsSelected: _onSongsSelected,
                    onClose: () {
                      setState(() {
                        _showAddSongsOverlay = false;
                      });
                    },
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
