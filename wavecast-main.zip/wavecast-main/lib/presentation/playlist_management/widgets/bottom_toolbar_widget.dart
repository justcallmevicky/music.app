import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BottomToolbarWidget extends StatelessWidget {
  final VoidCallback onAddSongs;
  final VoidCallback onShufflePlay;
  final VoidCallback onShare;
  final bool hasTrack;

  const BottomToolbarWidget({
    super.key,
    required this.onAddSongs,
    required this.onShufflePlay,
    required this.onShare,
    this.hasTrack = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: AppTheme.borderLight,
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            // Add songs button
            Expanded(
              child: ElevatedButton.icon(
                onPressed: onAddSongs,
                icon: CustomIconWidget(
                  iconName: 'add',
                  color: Colors.white,
                  size: 5.w,
                ),
                label: Text(
                  'Add Songs',
                  style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.primaryColor,
                  padding: EdgeInsets.symmetric(vertical: 1.5.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                ),
              ),
            ),
            if (hasTrack) ...[
              SizedBox(width: 3.w),
              // Shuffle play button
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: AppTheme.lightTheme.primaryColor,
                    width: 2,
                  ),
                ),
                child: IconButton(
                  onPressed: onShufflePlay,
                  icon: CustomIconWidget(
                    iconName: 'shuffle',
                    color: AppTheme.lightTheme.primaryColor,
                    size: 6.w,
                  ),
                  tooltip: 'Shuffle Play',
                ),
              ),
              SizedBox(width: 3.w),
              // Share button
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: AppTheme.borderLight,
                    width: 2,
                  ),
                ),
                child: IconButton(
                  onPressed: onShare,
                  icon: CustomIconWidget(
                    iconName: 'share',
                    color: AppTheme.textPrimaryLight,
                    size: 6.w,
                  ),
                  tooltip: 'Share Playlist',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
