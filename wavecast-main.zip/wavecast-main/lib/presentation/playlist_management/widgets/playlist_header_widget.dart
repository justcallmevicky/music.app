import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PlaylistHeaderWidget extends StatefulWidget {
  final String playlistTitle;
  final String creatorName;
  final String? coverImageUrl;
  final bool isEditable;
  final Function(String) onTitleChanged;
  final VoidCallback? onCoverTap;

  const PlaylistHeaderWidget({
    super.key,
    required this.playlistTitle,
    required this.creatorName,
    this.coverImageUrl,
    this.isEditable = true,
    required this.onTitleChanged,
    this.onCoverTap,
  });

  @override
  State<PlaylistHeaderWidget> createState() => _PlaylistHeaderWidgetState();
}

class _PlaylistHeaderWidgetState extends State<PlaylistHeaderWidget> {
  late TextEditingController _titleController;
  bool _isEditingTitle = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.playlistTitle);
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Playlist Cover
          GestureDetector(
            onTap: widget.onCoverTap,
            child: Container(
              width: 35.w,
              height: 35.w,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppTheme.lightTheme.colorScheme.surface
                    .withValues(alpha: 0.1),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.shadowLight,
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: widget.coverImageUrl != null
                    ? CustomImageWidget(
                        imageUrl: widget.coverImageUrl!,
                        width: 35.w,
                        height: 35.w,
                        fit: BoxFit.cover,
                      )
                    : Container(
                        color: AppTheme.lightTheme.colorScheme.primaryContainer,
                        child: Center(
                          child: CustomIconWidget(
                            iconName: 'music_note',
                            color: AppTheme.lightTheme.primaryColor,
                            size: 8.w,
                          ),
                        ),
                      ),
              ),
            ),
          ),
          SizedBox(width: 4.w),
          // Playlist Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title
                _isEditingTitle
                    ? TextField(
                        controller: _titleController,
                        style: AppTheme.lightTheme.textTheme.headlineSmall,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.zero,
                          isDense: true,
                        ),
                        onSubmitted: (value) {
                          setState(() {
                            _isEditingTitle = false;
                          });
                          widget.onTitleChanged(value);
                        },
                        onTapOutside: (_) {
                          setState(() {
                            _isEditingTitle = false;
                          });
                          widget.onTitleChanged(_titleController.text);
                        },
                        autofocus: true,
                        maxLines: 2,
                      )
                    : GestureDetector(
                        onTap: widget.isEditable
                            ? () {
                                setState(() {
                                  _isEditingTitle = true;
                                });
                              }
                            : null,
                        child: Text(
                          widget.playlistTitle,
                          style: AppTheme.lightTheme.textTheme.headlineSmall,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                SizedBox(height: 1.h),
                // Creator Info
                Row(
                  children: [
                    Text(
                      'Created by ',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                    Text(
                      widget.creatorName,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 0.5.h),
                // Edit hint
                if (widget.isEditable && !_isEditingTitle)
                  Text(
                    'Tap to edit title',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondaryLight,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
