import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum PlaylistPrivacy { public, private, friendsOnly }

class PrivacyToggleWidget extends StatelessWidget {
  final PlaylistPrivacy currentPrivacy;
  final Function(PlaylistPrivacy) onPrivacyChanged;

  const PrivacyToggleWidget({
    super.key,
    required this.currentPrivacy,
    required this.onPrivacyChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Privacy',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.borderLight,
                width: 1,
              ),
            ),
            child: Column(
              children: [
                _buildPrivacyOption(
                  PlaylistPrivacy.public,
                  'Public',
                  'Anyone can see and listen to this playlist',
                  'public',
                ),
                Divider(
                  height: 1,
                  color: AppTheme.borderLight,
                ),
                _buildPrivacyOption(
                  PlaylistPrivacy.private,
                  'Private',
                  'Only you can see and listen to this playlist',
                  'lock',
                ),
                Divider(
                  height: 1,
                  color: AppTheme.borderLight,
                ),
                _buildPrivacyOption(
                  PlaylistPrivacy.friendsOnly,
                  'Friends Only',
                  'Only your friends can see and listen to this playlist',
                  'group',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrivacyOption(
    PlaylistPrivacy privacy,
    String title,
    String description,
    String iconName,
  ) {
    final bool isSelected = currentPrivacy == privacy;

    return GestureDetector(
      onTap: () => onPrivacyChanged(privacy),
      child: Container(
        padding: EdgeInsets.all(3.w),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isSelected
                    ? AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1)
                    : AppTheme.lightTheme.colorScheme.surface
                        .withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: iconName,
                color: isSelected
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.textSecondaryLight,
                size: 5.w,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      color: isSelected
                          ? AppTheme.lightTheme.primaryColor
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    description,
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondaryLight,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              CustomIconWidget(
                iconName: 'check_circle',
                color: AppTheme.lightTheme.primaryColor,
                size: 5.w,
              ),
          ],
        ),
      ),
    );
  }
}
