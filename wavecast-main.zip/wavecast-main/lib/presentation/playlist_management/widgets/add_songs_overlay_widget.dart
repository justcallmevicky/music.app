import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AddSongsOverlayWidget extends StatefulWidget {
  final Function(List<Map<String, dynamic>>) onSongsSelected;
  final VoidCallback onClose;

  const AddSongsOverlayWidget({
    super.key,
    required this.onSongsSelected,
    required this.onClose,
  });

  @override
  State<AddSongsOverlayWidget> createState() => _AddSongsOverlayWidgetState();
}

class _AddSongsOverlayWidgetState extends State<AddSongsOverlayWidget>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final List<Map<String, dynamic>> _selectedSongs = [];

  final List<Map<String, dynamic>> _recentlyPlayed = [
    {
      "id": 1,
      "title": "Blinding Lights",
      "artist": "The Weeknd",
      "duration": 200,
      "artwork":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop"
    },
    {
      "id": 2,
      "title": "Watermelon Sugar",
      "artist": "Harry Styles",
      "duration": 174,
      "artwork":
          "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop"
    },
    {
      "id": 3,
      "title": "Levitating",
      "artist": "Dua Lipa",
      "duration": 203,
      "artwork":
          "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop"
    },
  ];

  final List<Map<String, dynamic>> _browseCategories = [
    {
      "name": "Pop Hits",
      "icon": "music_note",
      "color": 0xFFFF6B6B,
      "songs": [
        {
          "id": 4,
          "title": "As It Was",
          "artist": "Harry Styles",
          "duration": 167,
          "artwork":
              "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop"
        },
        {
          "id": 5,
          "title": "Heat Waves",
          "artist": "Glass Animals",
          "duration": 238,
          "artwork":
              "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop"
        },
      ]
    },
    {
      "name": "Rock Classics",
      "icon": "album",
      "color": 0xFF4ECDC4,
      "songs": [
        {
          "id": 6,
          "title": "Bohemian Rhapsody",
          "artist": "Queen",
          "duration": 355,
          "artwork":
              "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop"
        },
      ]
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Widget _buildSongItem(Map<String, dynamic> song) {
    final bool isSelected = _selectedSongs.any((s) => s['id'] == song['id']);

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: GestureDetector(
        onTap: () {
          setState(() {
            if (isSelected) {
              _selectedSongs.removeWhere((s) => s['id'] == song['id']);
            } else {
              _selectedSongs.add(song);
            }
          });
        },
        child: Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: isSelected
                ? AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1)
                : AppTheme.lightTheme.colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.borderLight,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: CustomImageWidget(
                  imageUrl: song['artwork'] as String,
                  width: 12.w,
                  height: 12.w,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      song['title'] as String,
                      style: AppTheme.lightTheme.textTheme.titleSmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      song['artist'] as String,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryLight,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Text(
                _formatDuration(song['duration'] as int),
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondaryLight,
                ),
              ),
              SizedBox(width: 3.w),
              CustomIconWidget(
                iconName: isSelected ? 'check_circle' : 'add_circle_outline',
                color: isSelected
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.textSecondaryLight,
                size: 6.w,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                GestureDetector(
                  onTap: widget.onClose,
                  child: CustomIconWidget(
                    iconName: 'close',
                    color: AppTheme.textPrimaryLight,
                    size: 6.w,
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: Text(
                    'Add Songs',
                    style:
                        AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (_selectedSongs.isNotEmpty)
                  ElevatedButton(
                    onPressed: () {
                      widget.onSongsSelected(_selectedSongs);
                      widget.onClose();
                    },
                    child: Text('Add (${_selectedSongs.length})'),
                  ),
              ],
            ),
          ),
          // Search bar
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search for songs, artists, or albums...',
                prefixIcon: Padding(
                  padding: EdgeInsets.all(3.w),
                  child: CustomIconWidget(
                    iconName: 'search',
                    color: AppTheme.textSecondaryLight,
                    size: 5.w,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 2.h),
          // Tabs
          TabBar(
            controller: _tabController,
            tabs: const [
              Tab(text: 'Recent'),
              Tab(text: 'Browse'),
              Tab(text: 'Search'),
            ],
          ),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Recently played
                ListView.builder(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  itemCount: _recentlyPlayed.length,
                  itemBuilder: (context, index) {
                    return _buildSongItem(_recentlyPlayed[index]);
                  },
                ),
                // Browse categories
                ListView.builder(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  itemCount: _browseCategories.length,
                  itemBuilder: (context, index) {
                    final category = _browseCategories[index];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 4.w, vertical: 1.h),
                          child: Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(2.w),
                                decoration: BoxDecoration(
                                  color: Color(category['color'] as int)
                                      .withValues(alpha: 0.2),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: CustomIconWidget(
                                  iconName: category['icon'] as String,
                                  color: Color(category['color'] as int),
                                  size: 5.w,
                                ),
                              ),
                              SizedBox(width: 3.w),
                              Text(
                                category['name'] as String,
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        ...(category['songs'] as List<Map<String, dynamic>>)
                            .map((song) => _buildSongItem(song)),
                        SizedBox(height: 2.h),
                      ],
                    );
                  },
                ),
                // Search results (placeholder)
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'search',
                        color: AppTheme.textSecondaryLight,
                        size: 15.w,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'Search for songs to add',
                        style:
                            AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
