import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TrackListItemWidget extends StatefulWidget {
  final Map<String, dynamic> track;
  final bool isDragging;
  final VoidCallback? onMoreTap;
  final VoidCallback? onDeleteTap;
  final VoidCallback? onMoveToTop;
  final VoidCallback? onAddToQueue;
  final VoidCallback? onTap;

  const TrackListItemWidget({
    super.key,
    required this.track,
    this.isDragging = false,
    this.onMoreTap,
    this.onDeleteTap,
    this.onMoveToTop,
    this.onAddToQueue,
    this.onTap,
  });

  @override
  State<TrackListItemWidget> createState() => _TrackListItemWidgetState();
}

class _TrackListItemWidgetState extends State<TrackListItemWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<Offset> _slideAnimation;
  bool _isSwipeMenuVisible = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(-0.3, 0),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggleSwipeMenu() {
    if (_isSwipeMenuVisible) {
      _animationController.reverse();
    } else {
      _animationController.forward();
    }
    setState(() {
      _isSwipeMenuVisible = !_isSwipeMenuVisible;
    });
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: Stack(
        children: [
          // Swipe actions background
          if (_isSwipeMenuVisible)
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () {
                        _toggleSwipeMenu();
                        widget.onMoveToTop?.call();
                      },
                      child: Container(
                        width: 15.w,
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.primaryColor
                              .withValues(alpha: 0.1),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(12),
                            bottomLeft: Radius.circular(12),
                          ),
                        ),
                        child: Center(
                          child: CustomIconWidget(
                            iconName: 'keyboard_arrow_up',
                            color: AppTheme.lightTheme.primaryColor,
                            size: 6.w,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _toggleSwipeMenu();
                        widget.onAddToQueue?.call();
                      },
                      child: Container(
                        width: 15.w,
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: AppTheme.accentLight.withValues(alpha: 0.1),
                        ),
                        child: Center(
                          child: CustomIconWidget(
                            iconName: 'queue_music',
                            color: AppTheme.accentLight,
                            size: 6.w,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _toggleSwipeMenu();
                        widget.onDeleteTap?.call();
                      },
                      child: Container(
                        width: 15.w,
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: AppTheme.errorLight.withValues(alpha: 0.1),
                          borderRadius: const BorderRadius.only(
                            topRight: Radius.circular(12),
                            bottomRight: Radius.circular(12),
                          ),
                        ),
                        child: Center(
                          child: CustomIconWidget(
                            iconName: 'delete',
                            color: AppTheme.errorLight,
                            size: 6.w,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          // Main track item
          SlideTransition(
            position: _slideAnimation,
            child: GestureDetector(
              onTap: widget.onTap,
              onHorizontalDragEnd: (details) {
                if (details.primaryVelocity! < -500) {
                  _toggleSwipeMenu();
                } else if (details.primaryVelocity! > 500 &&
                    _isSwipeMenuVisible) {
                  _toggleSwipeMenu();
                }
              },
              child: Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: widget.isDragging
                      ? AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1)
                      : AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: widget.isDragging
                        ? AppTheme.lightTheme.primaryColor
                        : AppTheme.borderLight,
                    width: widget.isDragging ? 2 : 1,
                  ),
                  boxShadow: widget.isDragging
                      ? [
                          BoxShadow(
                            color: AppTheme.shadowLight,
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  children: [
                    // Drag handle
                    CustomIconWidget(
                      iconName: 'drag_handle',
                      color: AppTheme.textSecondaryLight,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    // Album artwork
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CustomImageWidget(
                        imageUrl: widget.track['artwork'] as String? ?? '',
                        width: 12.w,
                        height: 12.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(width: 3.w),
                    // Track info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.track['title'] as String? ?? 'Unknown Title',
                            style: AppTheme.lightTheme.textTheme.titleSmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            widget.track['artist'] as String? ??
                                'Unknown Artist',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.textSecondaryLight,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    // Duration
                    Text(
                      _formatDuration(widget.track['duration'] as int? ?? 0),
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                    SizedBox(width: 3.w),
                    // More menu
                    GestureDetector(
                      onTap: widget.onMoreTap,
                      child: Container(
                        padding: EdgeInsets.all(1.w),
                        child: CustomIconWidget(
                          iconName: 'more_vert',
                          color: AppTheme.textSecondaryLight,
                          size: 5.w,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
