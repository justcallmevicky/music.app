import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class PlaylistDescriptionWidget extends StatefulWidget {
  final String description;
  final bool isEditable;
  final Function(String) onDescriptionChanged;

  const PlaylistDescriptionWidget({
    super.key,
    required this.description,
    this.isEditable = true,
    required this.onDescriptionChanged,
  });

  @override
  State<PlaylistDescriptionWidget> createState() =>
      _PlaylistDescriptionWidgetState();
}

class _PlaylistDescriptionWidgetState extends State<PlaylistDescriptionWidget> {
  late TextEditingController _descriptionController;
  bool _isEditing = false;
  final int _maxCharacters = 300;

  @override
  void initState() {
    super.initState();
    _descriptionController = TextEditingController(text: widget.description);
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Description',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          _isEditing
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    TextField(
                      controller: _descriptionController,
                      style: AppTheme.lightTheme.textTheme.bodyMedium,
                      decoration: InputDecoration(
                        hintText: 'Tell the story behind your playlist...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: AppTheme.borderLight),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: AppTheme.lightTheme.primaryColor,
                            width: 2,
                          ),
                        ),
                        contentPadding: EdgeInsets.all(3.w),
                      ),
                      maxLines: 4,
                      maxLength: _maxCharacters,
                      onChanged: (value) {
                        setState(() {});
                      },
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${_descriptionController.text.length}/$_maxCharacters',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: _descriptionController.text.length >
                                    _maxCharacters * 0.9
                                ? AppTheme.errorLight
                                : AppTheme.textSecondaryLight,
                          ),
                        ),
                        Row(
                          children: [
                            TextButton(
                              onPressed: () {
                                setState(() {
                                  _isEditing = false;
                                  _descriptionController.text =
                                      widget.description;
                                });
                              },
                              child: Text('Cancel'),
                            ),
                            SizedBox(width: 2.w),
                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  _isEditing = false;
                                });
                                widget.onDescriptionChanged(
                                    _descriptionController.text);
                              },
                              child: Text('Save'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                )
              : GestureDetector(
                  onTap: widget.isEditable
                      ? () {
                          setState(() {
                            _isEditing = true;
                          });
                        }
                      : null,
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.surface
                          .withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.borderLight,
                        width: 1,
                      ),
                    ),
                    child: widget.description.isEmpty
                        ? Text(
                            widget.isEditable
                                ? 'Tap to add a description...'
                                : 'No description available',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.textSecondaryLight,
                              fontStyle: FontStyle.italic,
                            ),
                          )
                        : Text(
                            widget.description,
                            style: AppTheme.lightTheme.textTheme.bodyMedium,
                          ),
                  ),
                ),
        ],
      ),
    );
  }
}
