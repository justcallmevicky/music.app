import 'package:flutter/material.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/music_player/music_player.dart';
import '../presentation/home_dashboard/home_dashboard.dart';
import '../presentation/search_and_browse/search_and_browse.dart';
import '../presentation/chat_and_messaging/chat_and_messaging.dart';
import '../presentation/playlist_management/playlist_management.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String loginScreen = '/login-screen';
  static const String musicPlayer = '/music-player';
  static const String homeDashboard = '/home-dashboard';
  static const String searchAndBrowse = '/search-and-browse';
  static const String chatAndMessaging = '/chat-and-messaging';
  static const String playlistManagement = '/playlist-management';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => LoginScreen(),
    loginScreen: (context) => LoginScreen(),
    musicPlayer: (context) => MusicPlayer(),
    homeDashboard: (context) => HomeDashboard(),
    searchAndBrowse: (context) => SearchAndBrowse(),
    chatAndMessaging: (context) => ChatAndMessaging(),
    playlistManagement: (context) => PlaylistManagement(),
    // TODO: Add your other routes here
  };
}
